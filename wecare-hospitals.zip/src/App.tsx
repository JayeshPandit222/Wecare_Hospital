/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import HomeSection from './components/HomeSection';
import AboutSection from './components/AboutSection';
import DepartmentsSection from './components/DepartmentsSection';
import DoctorsSection from './components/DoctorsSection';
import BookingSection from './components/BookingSection';
import AdminPortal from './components/AdminPortal';

export default function App() {
  const [activeTab, setActiveTab] = useState('home');
  const [selectedDepartmentId, setSelectedDepartmentId] = useState<string | null>(null);
  const [selectedDoctorId, setSelectedDoctorId] = useState<string | null>(null);

  // Smooth custom handler to change tabs and reset child filters if required
  const handleTabChange = (newTab: string) => {
    setActiveTab(newTab);
    // Scroll to top on tab change so user is at the start of the section
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const renderActiveSection = () => {
    switch (activeTab) {
      case 'home':
        return (
          <HomeSection 
            setActiveTab={handleTabChange} 
            setSelectedDepartmentId={(id) => {
              setSelectedDepartmentId(id);
              handleTabChange('departments');
            }} 
          />
        );
      case 'about':
        return <AboutSection />;
      case 'departments':
        return (
          <DepartmentsSection 
            selectedDepartmentId={selectedDepartmentId}
            setSelectedDepartmentId={setSelectedDepartmentId}
            setActiveTab={handleTabChange}
            setSelectedDoctorId={setSelectedDoctorId}
          />
        );
      case 'doctors':
        return (
          <DoctorsSection 
            activeTab={activeTab}
            setActiveTab={handleTabChange}
            selectedDoctorId={selectedDoctorId}
            setSelectedDoctorId={setSelectedDoctorId}
          />
        );
      case 'booking':
        return (
          <BookingSection 
            selectedDoctorId={selectedDoctorId}
            setSelectedDoctorId={setSelectedDoctorId}
          />
        );
      case 'admin':
        return <AdminPortal />;
      default:
        return (
          <HomeSection 
            setActiveTab={handleTabChange} 
            setSelectedDepartmentId={setSelectedDepartmentId} 
          />
        );
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50/50 text-slate-800 selection:bg-emerald-500 selection:text-white antialiased">
      {/* Global Clinical Navigation Header */}
      <Navbar activeTab={activeTab} setActiveTab={handleTabChange} />

      {/* Main Content Viewport with Motion transitions */}
      <main className="flex-grow pt-4">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.3, ease: 'easeInOut' }}
            className="w-full"
          >
            {renderActiveSection()}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Global Informative Footer */}
      <Footer setActiveTab={handleTabChange} />
    </div>
  );
}
