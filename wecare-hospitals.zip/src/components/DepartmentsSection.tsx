import { useState, useEffect } from 'react';
import { DEPARTMENTS, DOCTORS } from '../data';
import { Department, Doctor } from '../types';
import { 
  Heart, 
  Baby, 
  Brain, 
  Activity, 
  ShieldAlert, 
  Sparkles, 
  Search, 
  ArrowLeft, 
  UserCheck, 
  CheckCircle, 
  Calendar, 
  ChevronRight,
  Star,
  Clock,
  ArrowRight
} from 'lucide-react';

interface DepartmentsSectionProps {
  selectedDepartmentId: string | null;
  setSelectedDepartmentId: (deptId: string | null) => void;
  setActiveTab: (tab: string) => void;
  setSelectedDoctorId: (docId: string | null) => void;
}

export default function DepartmentsSection({
  selectedDepartmentId,
  setSelectedDepartmentId,
  setActiveTab,
  setSelectedDoctorId
}: DepartmentsSectionProps) {
  const [searchQuery, setSearchQuery] = useState('');
  
  // Custom helper function to get type-safe icons
  const getDeptIcon = (iconName: string, className = "w-6 h-6") => {
    switch (iconName) {
      case 'Heart': return <Heart className={className} />;
      case 'Baby': return <Baby className={className} />;
      case 'Brain': return <Brain className={className} />;
      case 'Activity': return <Activity className={className} />;
      case 'ShieldAlert': return <ShieldAlert className={className} />;
      default: return <Sparkles className={className} />;
    }
  };

  const filteredDepts = DEPARTMENTS.filter(
    (dept) =>
      dept.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      dept.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const activeDept = DEPARTMENTS.find((d) => d.id === selectedDepartmentId);
  const activeDoctors = DOCTORS.filter((doc) => doc.departmentId === selectedDepartmentId);

  const handleBookDoctor = (doctorId: string) => {
    setSelectedDoctorId(doctorId);
    setActiveTab('booking');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20 space-y-12" id="departments-section">
      {/* If no department is focused, show general grid with search */}
      {!activeDept ? (
        <>
          {/* Header & Search */}
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pt-6">
            <div className="space-y-3 max-w-xl">
              <span className="text-xs font-mono font-bold uppercase tracking-widest text-emerald-600">WECARE CLINICS</span>
              <h1 className="text-3xl font-bold text-slate-800 font-sans tracking-tight">
                Our Specialized Medical Departments
              </h1>
              <p className="text-slate-500 text-sm leading-relaxed">
                Discover our focused clinical sections. We combine seasoned senior consultants with advanced robotics and imaging suites.
              </p>
            </div>

            {/* Premium Search Input */}
            <div className="relative w-full md:w-80">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                placeholder="Search specialties or clinics..."
                value={searchQuery}
                id="dept-search-input"
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-50 text-sm transition-all bg-white"
              />
            </div>
          </div>

          {/* Departments Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredDepts.map((dept) => (
              <div
                key={dept.id}
                id={`dept-card-${dept.id}`}
                onClick={() => setSelectedDepartmentId(dept.id)}
                className="group bg-white border border-slate-100 rounded-3xl p-8 hover:shadow-lg transition-all duration-300 cursor-pointer flex flex-col justify-between hover:-translate-y-1"
              >
                <div className="space-y-6">
                  {/* Icon & Name Header */}
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center group-hover:bg-emerald-600 group-hover:text-white transition-all duration-300">
                      {getDeptIcon(dept.iconName, "w-7 h-7")}
                    </div>
                    <div>
                      <h3 className="text-lg font-bold text-slate-800 group-hover:text-emerald-700 transition-colors leading-tight">
                        {dept.name}
                      </h3>
                      <span className="text-[10px] uppercase font-mono tracking-widest text-slate-400 font-semibold">
                        Super Specialty Center
                      </span>
                    </div>
                  </div>

                  <p className="text-slate-500 text-sm leading-relaxed">
                    {dept.description}
                  </p>

                  {/* Highlights Bullet List */}
                  <ul className="space-y-2 text-xs text-slate-400 font-medium">
                    {dept.specialties.slice(0, 3).map((spec, i) => (
                      <li key={i} className="flex items-center gap-2">
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                        <span className="truncate">{spec}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Footer details */}
                <div className="pt-6 mt-8 border-t border-slate-50 flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-400 uppercase font-mono tracking-wide">
                    {dept.stats[0].value} {dept.stats[0].label.replace('/Yr', '')}
                  </span>
                  <span className="text-emerald-600 group-hover:translate-x-1.5 transition-transform duration-300 font-bold flex items-center gap-1">
                    Explore Details
                    <ArrowRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            ))}

            {filteredDepts.length === 0 && (
              <div className="col-span-full py-16 text-center text-slate-400 space-y-4">
                <p className="text-sm">We couldn't find any department matching your keyword query.</p>
                <button 
                  onClick={() => setSearchQuery('')}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-mono rounded-lg transition-colors cursor-pointer"
                >
                  Clear search filters
                </button>
              </div>
            )}
          </div>
        </>
      ) : (
        /* Detailed View of Focused Department */
        <div className="space-y-12">
          {/* Back button */}
          <div>
            <button
              onClick={() => setSelectedDepartmentId(null)}
              id="dept-back-btn"
              className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50 flex items-center gap-2 text-sm font-medium transition-all cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Departments
            </button>
          </div>

          {/* Department Main Spotlight Hero */}
          <div className="bg-slate-900 rounded-3xl p-8 sm:p-12 text-white relative overflow-hidden">
            <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
            
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center relative z-10">
              {/* Info columns */}
              <div className="lg:col-span-8 space-y-6">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-emerald-500 text-slate-900 flex items-center justify-center font-bold">
                    {getDeptIcon(activeDept.iconName, "w-7 h-7")}
                  </div>
                  <div>
                    <span className="text-xxs font-mono text-emerald-400 tracking-widest font-bold uppercase block">DEPARTMENT FOCUS</span>
                    <h1 className="text-3xl font-extrabold text-white tracking-tight font-sans">
                      {activeDept.name} Department
                    </h1>
                  </div>
                </div>

                <p className="text-slate-300 leading-relaxed text-sm antialiased font-sans">
                  {activeDept.longDescription}
                </p>

                {/* Specialties Bullet Block */}
                <div className="space-y-3">
                  <span className="block text-xs uppercase font-mono tracking-widest text-emerald-400 font-bold">Key Sub-specialties Covered:</span>
                  <div className="flex flex-wrap gap-2.5">
                    {activeDept.specialties.map((spec, i) => (
                      <span key={i} className="px-3.5 py-1.5 rounded-xl bg-slate-800 text-slate-200 text-xs border border-slate-800">
                        {spec}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Stats column */}
              <div className="lg:col-span-4 bg-slate-800/80 border border-slate-800 rounded-2xl p-6 space-y-6">
                <h3 className="font-bold text-sm tracking-widest text-white uppercase font-mono border-b border-slate-700/60 pb-3">
                  Clinical Footprint
                </h3>
                <div className="space-y-4">
                  {activeDept.stats.map((st, i) => (
                    <div key={i} className="flex justify-between items-center text-sm">
                      <span className="text-slate-400 font-sans">{st.label}</span>
                      <span className="font-bold font-mono text-emerald-400 text-base">{st.value}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Doctors available in focused department */}
          <div className="space-y-6">
            <div className="space-y-2">
              <span className="text-xs font-mono font-bold text-emerald-600 uppercase">OUR ON-SITE SPECIALISTS</span>
              <h2 className="text-2xl font-bold text-slate-800 font-sans tracking-tight">
                Doctors Practicing in {activeDept.name}
              </h2>
              <p className="text-slate-500 text-xs">
                To consult either specialist directly, select a slot profile to proceed with automatic appointment assignment.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {activeDoctors.map((doc) => (
                <div key={doc.id} className="bg-white border border-slate-100 rounded-3xl p-6 shadow-sm hover:shadow-md transition-all duration-300 flex flex-col sm:flex-row gap-6">
                  {/* Image Column */}
                  <div className="w-full sm:w-36 h-44 rounded-2xl overflow-hidden shrink-0 relative bg-slate-50 flex items-center justify-center">
                    <img 
                      src={doc.image} 
                      alt={doc.name} 
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  </div>

                  {/* Doctor Info Detail */}
                  <div className="flex flex-col justify-between flex-1 space-y-4">
                    <div className="space-y-2">
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="font-extrabold text-slate-800 text-base tracking-tight">{doc.name}</h4>
                          <span className="text-xxs font-semibold font-mono text-emerald-600 uppercase tracking-wider block">{doc.role}</span>
                        </div>
                        <div className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-amber-50 text-amber-700 text-xs font-bold shrink-0">
                          <Star className="w-3.5 h-3.5 fill-current" />
                          <span>{doc.rating}</span>
                        </div>
                      </div>

                      <p className="text-xs text-slate-500 line-clamp-2 italic leading-relaxed">
                        "{doc.bio}"
                      </p>

                      <div className="text-xxs text-slate-400 font-semibold space-y-1">
                        <span className="block"><strong>Education:</strong> {doc.education}</span>
                        <span className="block"><strong>Experience:</strong> {doc.experience} Clinical Work</span>
                      </div>
                    </div>

                    <div className="pt-3 border-t border-slate-50 flex items-center justify-between">
                      <div className="text-xxs text-slate-400">
                        <span className="block uppercase font-mono tracking-wider font-bold">Weekdays</span>
                        <span className="block text-slate-600 font-medium">{doc.availability.days.join(', ')}</span>
                      </div>
                      
                      <button
                        onClick={() => handleBookDoctor(doc.id)}
                        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-sm hover:shadow-md transition-all flex items-center gap-1 cursor-pointer"
                      >
                        <UserCheck className="w-3.5 h-3.5" />
                        Book Consult
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
