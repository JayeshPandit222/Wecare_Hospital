import { useState, useEffect, useMemo, FormEvent } from 'react';
import { DOCTORS, DEPARTMENTS } from '../data';
import { Appointment, Doctor } from '../types';
import { useAuth, UserProfile } from '../context/AuthContext';
import { 
  Calendar, 
  Clock, 
  Stethoscope, 
  User, 
  Mail, 
  Phone, 
  FileText, 
  CheckCircle, 
  Trash2, 
  AlertCircle, 
  Search, 
  PlusCircle, 
  SlidersHorizontal, 
  Check, 
  X, 
  TrendingUp, 
  ShieldAlert, 
  ShieldCheck, 
  Users, 
  CalendarDays, 
  UserPlus,
  RefreshCw
} from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { 
  collection, 
  doc, 
  query, 
  collectionGroup, 
  onSnapshot, 
  setDoc, 
  deleteDoc, 
  updateDoc, 
  serverTimestamp, 
  getDocs 
} from 'firebase/firestore';
import { motion, AnimatePresence } from 'motion/react';

export default function AdminPortal() {
  const { user, userProfile } = useAuth();

  // Firestore collections state
  const [allAppointments, setAllAppointments] = useState<Appointment[]>([]);
  const [allUsers, setAllUsers] = useState<UserProfile[]>([]);
  const [loadingAppts, setLoadingAppts] = useState(true);
  const [loadingUsers, setLoadingUsers] = useState(true);
  
  // Dashboard view states
  const [activeSubTab, setActiveSubTab] = useState<'all' | 'Scheduled' | 'Completed' | 'Cancelled'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterDeptId, setFilterDeptId] = useState('');
  const [filterDocId, setFilterDocId] = useState('');
  
  // Form toggles
  const [isAddingBooking, setIsAddingBooking] = useState(false);
  const [bookingMode, setBookingMode] = useState<'existing' | 'new'>('existing');

  // Form states for adding booking
  const [selectedUserUid, setSelectedUserUid] = useState('');
  const [newPatientName, setNewPatientName] = useState('');
  const [newPatientEmail, setNewPatientEmail] = useState('');
  const [newPatientPhone, setNewPatientPhone] = useState('');
  
  const [selectedDeptId, setSelectedDeptId] = useState('');
  const [selectedDocIdInternal, setSelectedDocIdInternal] = useState('');
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedSlot, setSelectedSlot] = useState('');
  const [symptoms, setSymptoms] = useState('');
  const [formError, setFormError] = useState('');
  const [formSuccess, setFormSuccess] = useState('');

  // 1. Listen for ALL user profiles (Admins are authorized)
  useEffect(() => {
    if (!user) return;
    
    const path = 'users';
    const q = query(collection(db, path));
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      try {
        const usersList = snapshot.docs.map(docSnap => {
          const data = docSnap.data();
          return {
            userId: docSnap.id,
            name: data.name || 'Anonymous Patient',
            email: data.email || '',
            phone: data.phone || '',
            createdAt: data.createdAt,
            updatedAt: data.updatedAt
          } as UserProfile;
        });
        
        setAllUsers(usersList);
        setLoadingUsers(false);
        
        // Pick the first user in list as default choice for booking form
        if (usersList.length > 0 && !selectedUserUid) {
          setSelectedUserUid(usersList[0].userId);
        }
      } catch (err) {
        handleFirestoreError(err, OperationType.GET, path);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, path);
    });

    return () => unsubscribe();
  }, [user]);

  // 2. Listen for ALL appointments globally via Collection Group Query (Admins are authorized)
  useEffect(() => {
    if (!user) return;

    const queryGroup = query(collectionGroup(db, 'appointments'));

    const unsubscribe = onSnapshot(queryGroup, (snapshot) => {
      try {
        const loaded: Appointment[] = snapshot.docs.map(docSnap => {
          const data = docSnap.data();
          return {
            id: docSnap.id,
            userId: data.userId, // Stored relational link
            doctorId: data.doctorId,
            doctorName: data.doctorName,
            departmentId: data.departmentId,
            departmentName: data.departmentName,
            patientName: data.patientName,
            patientEmail: data.patientEmail,
            patientPhone: data.patientPhone,
            date: data.date,
            timeSlot: data.timeSlot,
            symptoms: data.symptoms,
            status: data.status,
            createdAt: data.createdAt ? (data.createdAt.toDate ? data.createdAt.toDate().toISOString() : data.createdAt) : new Date().toISOString()
          } as Appointment;
        });

        // Default sort chronologically by date descending
        loaded.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
        setAllAppointments(loaded);
        setLoadingAppts(false);
      } catch (err) {
        handleFirestoreError(err, OperationType.GET, 'appointments');
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'appointments');
    });

    return () => unsubscribe();
  }, [user]);

  // Statistics Computations
  const stats = useMemo(() => {
    const total = allAppointments.length;
    const scheduled = allAppointments.filter(a => a.status === 'Scheduled').length;
    const completed = allAppointments.filter(a => a.status === 'Completed').length;
    const cancelled = allAppointments.filter(a => a.status === 'Cancelled').length;
    const uniquePatients = allUsers.length;

    return { total, scheduled, completed, cancelled, uniquePatients };
  }, [allAppointments, allUsers]);

  // Dynamic filter for physicians in booking form
  const formDoctors = useMemo(() => {
    if (!selectedDeptId) return [];
    return DOCTORS.filter(d => d.departmentId === selectedDeptId);
  }, [selectedDeptId]);

  const activeFormDoctor = useMemo(() => {
    return DOCTORS.find(d => d.id === selectedDocIdInternal);
  }, [selectedDocIdInternal]);

  // Clean filters for physicians in view-query controls
  const filterDoctorsList = useMemo(() => {
    if (!filterDeptId) return [];
    return DOCTORS.filter(d => d.departmentId === filterDeptId);
  }, [filterDeptId]);

  // Apply search query, category filters, and status tab filtering
  const filteredAppointments = useMemo(() => {
    return allAppointments.filter(apt => {
      // 1. Status Check
      if (activeSubTab !== 'all' && apt.status !== activeSubTab) {
        return false;
      }

      // 2. Department Check
      if (filterDeptId && apt.departmentId !== filterDeptId) {
        return false;
      }

      // 3. Doctor Check
      if (filterDocId && apt.doctorId !== filterDocId) {
        return false;
      }

      // 4. Keyword Query String matching
      if (searchQuery.trim()) {
        const queryNorm = searchQuery.toLowerCase();
        const matchesName = apt.patientName.toLowerCase().includes(queryNorm);
        const matchesEmail = apt.patientEmail.toLowerCase().includes(queryNorm);
        const matchesPhone = apt.patientPhone.toLowerCase().includes(queryNorm);
        const matchesDoc = apt.doctorName.toLowerCase().includes(queryNorm);
        const matchesId = apt.id.toLowerCase().includes(queryNorm);
        return matchesName || matchesEmail || matchesPhone || matchesDoc || matchesId;
      }

      return true;
    });
  }, [allAppointments, activeSubTab, filterDeptId, filterDocId, searchQuery]);

  // Action: Transition single appointment state
  const updateAppointmentStatus = async (apt: Appointment, nextStatus: 'Scheduled' | 'Completed' | 'Cancelled') => {
    const path = `users/${apt.userId}/appointments/${apt.id}`;
    try {
      await updateDoc(doc(db, `users/${apt.userId}/appointments`, apt.id), {
        status: nextStatus,
        updatedAt: serverTimestamp()
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, path);
    }
  };

  // Action: Hard delete booking entries
  const deleteAppointment = async (apt: Appointment) => {
    if (confirm(`Are you absolutely sure you wish to delete appointment ${apt.id}? This cannot be undone.`)) {
      const path = `users/${apt.userId}/appointments/${apt.id}`;
      try {
        await deleteDoc(doc(db, `users/${apt.userId}/appointments`, apt.id));
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, path);
      }
    }
  };

  // Action: Submit a brand new booking from the admin end
  const handleAdminAddBooking = async (e: FormEvent) => {
    e.preventDefault();
    setFormError('');
    setFormSuccess('');

    // Pre-validations
    if (!selectedDeptId) return setFormError('Select a clinic department.');
    if (!selectedDocIdInternal) return setFormError('Select an executive physician.');
    if (!selectedDate) return setFormError('Choose a calendar schedule date.');
    if (!selectedSlot) return setFormError('Choose an hour slot.');

    let targetUid = selectedUserUid;

    // Handle patient profile linkage
    if (bookingMode === 'new') {
      if (!newPatientName.trim()) return setFormError('Specify patient full legal name.');
      if (!newPatientEmail.trim()) return setFormError('Input patient email address.');
      if (!newPatientPhone.trim()) return setFormError('Provide patient contact phone.');

      // Standard custom UID generation for the walk-in patient profile
      targetUid = `user-${Math.random().toString(36).substr(2, 9)}`;

      // Create patient user document dynamically
      const userPayload = {
        userId: targetUid,
        name: newPatientName.trim(),
        email: newPatientEmail.trim(),
        phone: newPatientPhone.trim(),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };

      try {
        await setDoc(doc(db, 'users', targetUid), userPayload);
      } catch (err) {
        try {
          handleFirestoreError(err, OperationType.CREATE, `users/${targetUid}`);
        } catch (fErr: any) {
          return setFormError(`Profile Provision Failed: ${fErr.message}`);
        }
      }
    } else {
      if (!targetUid) return setFormError('Select an active patient account.');
    }

    const matchedUser = allUsers.find(u => u.userId === targetUid);
    const resolvedName = bookingMode === 'new' ? newPatientName.trim() : (matchedUser?.name || 'Patient');
    const resolvedEmail = bookingMode === 'new' ? newPatientEmail.trim() : (matchedUser?.email || '');
    const resolvedPhone = bookingMode === 'new' ? newPatientPhone.trim() : (matchedUser?.phone || '');

    const activeDept = DEPARTMENTS.find(d => d.id === selectedDeptId);
    const activeDoc = DOCTORS.find(d => d.id === selectedDocIdInternal);
    const newAptId = `apt-${Math.random().toString(36).substr(2, 9)}`;

    const bookingPayload = {
      id: newAptId,
      userId: targetUid,
      doctorId: selectedDocIdInternal,
      doctorName: activeDoc?.name || 'Practitioner',
      departmentId: selectedDeptId,
      departmentName: activeDept?.name || 'Outpatient Clinic',
      patientName: resolvedName,
      patientEmail: resolvedEmail,
      patientPhone: resolvedPhone,
      date: selectedDate,
      timeSlot: selectedSlot,
      symptoms: symptoms.trim() || 'Booked directly by administration registrar.',
      status: 'Scheduled',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    };

    const aptPath = `users/${targetUid}/appointments`;

    try {
      await setDoc(doc(db, aptPath, newAptId), bookingPayload);
      
      setFormSuccess(`Consultation ticket ${newAptId} provisioned and linked successfully!`);
      
      // Reset form variables
      setNewPatientName('');
      setNewPatientEmail('');
      setNewPatientPhone('');
      setSelectedDate('');
      setSelectedSlot('');
      setSymptoms('');
      
      // Keep on same tab, close after delay
      setTimeout(() => {
        setIsAddingBooking(false);
        setFormSuccess('');
      }, 2000);
    } catch (err) {
      try {
        handleFirestoreError(err, OperationType.CREATE, `${aptPath}/${newAptId}`);
      } catch (fErr: any) {
        setFormError(fErr.message);
      }
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20 space-y-8" id="admin-hub-container">
      {/* Banner Header with Admin credentials acknowledgment */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-6 shadow-xl border border-slate-800">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-black uppercase tracking-widest text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-full flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5" /> SYSTEM ADMINISTRATOR ACCESS
            </span>
          </div>
          <h1 className="text-3xl font-black font-sans tracking-tight">Executive Registrars Terminal</h1>
          <p className="text-slate-400 text-sm leading-relaxed max-w-xl">
            Logged in as <span className="text-emerald-300 font-bold">{userProfile?.name}</span> ({userProfile?.email}).
            You possess full clinical authorization to audit, create, schedule, reschedule, and revoke outpatient consultation tickets.
          </p>
        </div>

        <button
          onClick={() => setIsAddingBooking(true)}
          className="px-5 py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black font-mono text-xs uppercase tracking-wider rounded-xl transition-all shadow-lg hover:shadow-emerald-900/40 flex items-center gap-2 self-start md:self-auto cursor-pointer"
        >
          <PlusCircle className="w-4 h-4" /> Add New Booking
        </button>
      </div>

      {/* Grid Quick statistics counters */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        {/* Stat card: Total */}
        <div className="bg-white border border-slate-100 p-5 rounded-2xl flex flex-col justify-between shadow-xs">
          <span className="text-[10px] font-bold font-mono text-slate-400 uppercase tracking-widest">Total Bookings</span>
          <div className="flex items-baseline gap-2 mt-4">
            <span className="text-3xl font-black text-slate-800 font-sans">{stats.total}</span>
            <span className="text-xxs font-bold text-slate-400 font-mono">Tickets</span>
          </div>
        </div>

        {/* Stat card: Scheduled */}
        <div className="bg-white border border-slate-100 p-5 rounded-2xl flex flex-col justify-between shadow-xs border-l-4 border-l-emerald-500">
          <span className="text-[10px] font-bold font-mono text-emerald-600 uppercase tracking-widest">Scheduled</span>
          <div className="flex items-baseline gap-2 mt-4">
            <span className="text-3xl font-black text-emerald-600 font-sans">{stats.scheduled}</span>
            <span className="text-emerald-500 font-bold text-[10px] font-mono">{(stats.total ? Math.round((stats.scheduled/stats.total)*100) : 0)}%</span>
          </div>
        </div>

        {/* Stat card: Completed */}
        <div className="bg-white border border-slate-100 p-5 rounded-2xl flex flex-col justify-between shadow-xs border-l-4 border-l-sky-500">
          <span className="text-[10px] font-bold font-mono text-sky-600 uppercase tracking-widest font-black">Completed</span>
          <div className="flex items-baseline gap-2 mt-4">
            <span className="text-3xl font-black text-sky-600 font-sans">{stats.completed}</span>
            <span className="text-sky-500 text-[10px] font-mono">Processed</span>
          </div>
        </div>

        {/* Stat card: Cancelled */}
        <div className="bg-white border border-slate-100 p-5 rounded-2xl flex flex-col justify-between shadow-xs border-l-4 border-l-amber-500">
          <span className="text-[10px] font-bold font-mono text-amber-600 uppercase tracking-widest">Cancelled</span>
          <div className="flex items-baseline gap-2 mt-4">
            <span className="text-3xl font-black text-amber-600 font-sans">{stats.cancelled}</span>
            <span className="text-amber-500 text-[10px] font-mono">Revoked</span>
          </div>
        </div>

        {/* Stat card: Unique Patients */}
        <div className="bg-white border border-slate-100 p-5 rounded-2xl col-span-2 md:col-span-1 flex flex-col justify-between shadow-xs">
          <span className="text-[10px] font-bold font-mono text-slate-400 uppercase tracking-widest">Unique Patients</span>
          <div className="flex items-baseline gap-3 mt-4">
            <span className="text-3xl font-black text-slate-800 font-sans">{stats.uniquePatients}</span>
            <span className="text-xxs font-mono text-slate-400">Profiles</span>
          </div>
        </div>
      </div>

      {/* Main Core Workstation Area */}
      <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-sm space-y-6">
        {/* Dynamic Filters Bar */}
        <div className="flex flex-col lg:flex-row gap-4 justify-between items-stretch lg:items-center bg-slate-50 p-4 rounded-2xl border border-slate-100">
          {/* Key query query */}
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-slate-400" />
            <input
              type="text"
              placeholder="Search by patient name, email, phone, physician, slot ID..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-50 text-xs transition-all bg-white font-medium"
            />
          </div>

          <div className="flex flex-wrap sm:flex-nowrap gap-3">
            {/* Department Filter */}
            <select
              value={filterDeptId}
              onChange={(e) => {
                setFilterDeptId(e.target.value);
                setFilterDocId(''); // reset doctor filter on department switch
              }}
              className="px-3 py-2.5 rounded-xl border border-slate-200 text-xs bg-white outline-none focus:border-emerald-500 font-medium text-slate-700 min-w-[150px] cursor-pointer"
            >
              <option value="">All Departments</option>
              {DEPARTMENTS.map(d => (
                <option key={d.id} value={d.id}>{d.name}</option>
              ))}
            </select>

            {/* Doctor Filter */}
            <select
              value={filterDocId}
              onChange={(e) => setFilterDocId(e.target.value)}
              disabled={!filterDeptId}
              className="px-3 py-2.5 rounded-xl border border-slate-200 text-xs bg-white disabled:bg-slate-50 outline-none focus:border-emerald-500 font-medium text-slate-700 min-w-[155px] cursor-pointer"
            >
              <option value="">All Specialists</option>
              {filterDoctorsList.map(doc => (
                <option key={doc.id} value={doc.id}>{doc.name}</option>
              ))}
            </select>

            {/* Quick stats clear filters */}
            {(filterDeptId || filterDocId || searchQuery) && (
              <button
                onClick={() => {
                  setFilterDeptId('');
                  setFilterDocId('');
                  setSearchQuery('');
                }}
                className="px-3 py-2.5 bg-slate-800 text-white font-bold font-mono text-[10px] uppercase rounded-xl hover:bg-slate-900 transition-colors cursor-pointer"
              >
                Clear
              </button>
            )}
          </div>
        </div>

        {/* View Segment Sorting Tabs */}
        <div className="flex border-b border-slate-100 pb-px">
          <button
            onClick={() => setActiveSubTab('all')}
            className={`pb-3.5 px-6 font-mono text-xs font-bold uppercase tracking-wider border-b-2 transition-all cursor-pointer ${
              activeSubTab === 'all'
                ? 'border-emerald-600 text-emerald-600 font-black'
                : 'border-transparent text-slate-400 hover:text-slate-600'
            }`}
          >
            All Bookings ({allAppointments.length})
          </button>
          <button
            onClick={() => setActiveSubTab('Scheduled')}
            className={`pb-3.5 px-6 font-mono text-xs font-bold uppercase tracking-wider border-b-2 transition-all cursor-pointer ${
              activeSubTab === 'Scheduled'
                ? 'border-emerald-600 text-emerald-600 font-black'
                : 'border-transparent text-slate-400 hover:text-slate-600'
            }`}
          >
            Scheduled ({allAppointments.filter(a => a.status === 'Scheduled').length})
          </button>
          <button
            onClick={() => setActiveSubTab('Completed')}
            className={`pb-3.5 px-6 font-mono text-xs font-bold uppercase tracking-wider border-b-2 transition-all cursor-pointer ${
              activeSubTab === 'Completed'
                ? 'border-emerald-600 text-emerald-600 font-black'
                : 'border-transparent text-slate-400 hover:text-slate-600'
            }`}
          >
            Completed ({allAppointments.filter(a => a.status === 'Completed').length})
          </button>
          <button
            onClick={() => setActiveSubTab('Cancelled')}
            className={`pb-3.5 px-6 font-mono text-xs font-bold uppercase tracking-wider border-b-2 transition-all cursor-pointer ${
              activeSubTab === 'Cancelled'
                ? 'border-emerald-600 text-emerald-600 font-black'
                : 'border-transparent text-slate-400 hover:text-slate-600'
            }`}
          >
            Cancelled ({allAppointments.filter(a => a.status === 'Cancelled').length})
          </button>
        </div>

        {/* Loading spinners */}
        {loadingAppts ? (
          <div className="py-24 text-center space-y-4">
            <RefreshCw className="w-8 h-8 text-emerald-600 animate-spin mx-auto" />
            <p className="font-mono text-xs text-slate-400">Syncing with hospital registry in Firestore...</p>
          </div>
        ) : (
          <div className="overflow-x-auto rounded-2xl border border-slate-100">
            <table className="w-full text-left border-collapse text-xs font-sans">
              <thead>
                <tr className="bg-slate-50 text-slate-500 font-mono text-[10px] uppercase border-b border-slate-100 font-semibold select-none">
                  <th className="p-4 pl-6">Appointment ID</th>
                  <th className="p-4">Patient Profile</th>
                  <th className="p-4">Physician assigned</th>
                  <th className="p-4">Clinic Department</th>
                  <th className="p-4">Schedule Time</th>
                  <th className="p-4 text-center">Ticket Status</th>
                  <th className="p-4 pr-6 text-center">Administrative Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredAppointments.map((apt) => (
                  <tr 
                    key={apt.id} 
                    id={`admin-apt-tr-${apt.id}`}
                    className="hover:bg-slate-50/50 transition-colors group"
                  >
                    {/* Code ID */}
                    <td className="p-4 pl-6 font-mono font-bold text-slate-400 uppercase">
                      {apt.id}
                    </td>

                    {/* Patient detail summary */}
                    <td className="p-4">
                      <div className="space-y-0.5">
                        <span className="block font-bold text-slate-800 text-xs">{apt.patientName}</span>
                        <span className="block text-xxs font-mono text-slate-400">{apt.patientEmail}</span>
                        <span className="block text-xxs font-mono text-slate-400">{apt.patientPhone}</span>
                      </div>
                    </td>

                    {/* Consulting Speciality */}
                    <td className="p-4 text-slate-700 font-bold">
                      {apt.doctorName}
                    </td>

                    {/* Department name */}
                    <td className="p-4 text-slate-500">
                      <span className="bg-slate-100/70 border border-slate-200/50 text-[10px] font-mono uppercase font-semibold text-slate-600 tracking-wider px-2 py-0.5 rounded-md">
                        {apt.departmentName}
                      </span>
                    </td>

                    {/* Schedule block */}
                    <td className="p-4">
                      <div className="space-y-0.5 text-slate-600">
                        <span className="block font-bold font-mono text-[11px]">{apt.date}</span>
                        <span className="block font-mono text-xxs text-slate-400">{apt.timeSlot}</span>
                      </div>
                    </td>

                    {/* Pill highlights for patient lobby status */}
                    <td className="p-4 text-center">
                      <span className={`inline-block px-2.5 py-1 rounded-full text-[9px] font-mono uppercase font-extrabold tracking-wider ${
                        apt.status === 'Scheduled' 
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' 
                          : apt.status === 'Completed'
                          ? 'bg-sky-50 text-sky-700 border border-sky-100'
                          : 'bg-amber-50 text-amber-700 border border-amber-100'
                      }`}>
                        {apt.status}
                      </span>
                    </td>

                    {/* Interactive workflow selectors */}
                    <td className="p-4 pr-6">
                      <div className="flex items-center justify-center gap-2">
                        {/* Process status transition (Scheduled -> Completed) */}
                        {apt.status === 'Scheduled' && (
                          <>
                            <button
                              onClick={() => updateAppointmentStatus(apt, 'Completed')}
                              id={`admin-btn-complete-${apt.id}`}
                              className="p-1.5 rounded-xl bg-slate-55 border border-slate-200 text-slate-500 hover:text-sky-600 hover:bg-sky-50 hover:border-sky-100 transition-all cursor-pointer"
                              title="Complete consultation successfully"
                            >
                              <Check className="w-4 h-4" />
                            </button>

                            {/* Reschedule status cancellation */}
                            <button
                              onClick={() => updateAppointmentStatus(apt, 'Cancelled')}
                              id={`admin-btn-cancel-${apt.id}`}
                              className="p-1.5 rounded-xl bg-slate-55 border border-slate-200 text-slate-500 hover:text-amber-600 hover:bg-amber-50 hover:border-amber-100 transition-all cursor-pointer"
                              title="Mark consultation as Cancelled"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </>
                        )}

                        {/* Reset cancelled back to Scheduled */}
                        {apt.status === 'Cancelled' && (
                          <button
                            onClick={() => updateAppointmentStatus(apt, 'Scheduled')}
                            id={`admin-btn-scheduled-${apt.id}`}
                            className="p-1.5 rounded-xl bg-slate-55 border border-slate-200 text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 hover:border-emerald-100 transition-all cursor-pointer text-xxs font-black font-mono uppercase px-2.5"
                            title="Re-schedule consultation"
                          >
                            Restore
                          </button>
                        )}

                        {/* Drop consultation code altogether */}
                        <button
                          onClick={() => deleteAppointment(apt)}
                          id={`admin-btn-delete-${apt.id}`}
                          className="p-1.5 rounded-xl border border-slate-200 text-slate-400 hover:text-red-500 hover:bg-red-50 hover:border-red-100 transition-all cursor-pointer"
                          title="Purge appointment record"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}

                {filteredAppointments.length === 0 && (
                  <tr>
                    <td colSpan={7} className="text-center py-20 text-slate-450 font-mono text-xs">
                      <AlertCircle className="w-8 h-8 text-slate-300 mx-auto mb-3 animate-pulse" />
                      No matching outpatient registry bookings found. Try adjusting filters.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Slideout Bottom or Modal for Adding dynamic booking */}
      <AnimatePresence>
        {isAddingBooking && (
          <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-3xl p-6 sm:p-8 w-full max-w-2xl shadow-2xl space-y-6 border border-slate-100 max-h-[90vh] overflow-y-auto no-scrollbar"
              id="admin-add-booking-modal"
            >
              <div className="flex justify-between items-center border-b border-slate-100 pb-4">
                <div className="space-y-1">
                  <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-emerald-600">HOSPITAL REGISTRAR</span>
                  <h3 className="text-xl font-bold text-slate-800">Provision Outpatient Slot</h3>
                </div>
                <button
                  onClick={() => setIsAddingBooking(false)}
                  className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-full transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Status notifications */}
              {formError && (
                <div className="p-4 bg-red-50 text-red-700 border border-red-200 rounded-xl text-xs font-medium flex items-center gap-2">
                  <AlertCircle className="w-4.5 h-4.5 shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              {formSuccess && (
                <div className="p-4 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-xl text-xs font-bold flex items-center gap-2">
                  <CheckCircle className="w-4.5 h-4.5 shrink-0" />
                  <span>{formSuccess}</span>
                </div>
              )}

              {/* Action Form */}
              <form onSubmit={handleAdminAddBooking} className="space-y-6 text-slate-700 text-xs">
                
                {/* Mode Selector */}
                <div className="space-y-2">
                  <label className="block text-xs uppercase font-mono tracking-wider font-bold text-slate-400">
                    Patient Search Scope
                  </label>
                  <div className="flex gap-4">
                    <label className="flex items-center gap-2 bg-slate-50 border border-slate-200 px-4 py-3 rounded-xl cursor-pointer flex-1 font-semibold hover:bg-slate-100 transition-colors">
                      <input 
                        type="radio" 
                        name="bookingMode" 
                        checked={bookingMode === 'existing'}
                        onChange={() => setBookingMode('existing')}
                        className="text-emerald-600 focus:ring-emerald-50"
                      />
                      <span>Select Registered Clinic Patient</span>
                    </label>
                    <label className="flex items-center gap-2 bg-slate-50 border border-slate-200 px-4 py-3 rounded-xl cursor-pointer flex-1 font-semibold hover:bg-slate-100 transition-colors">
                      <input 
                        type="radio" 
                        name="bookingMode" 
                        checked={bookingMode === 'new'}
                        onChange={() => setBookingMode('new')}
                        className="text-emerald-600 focus:ring-emerald-50"
                      />
                      <span>Register New / Phone Walk-in</span>
                    </label>
                  </div>
                </div>

                {/* Patient Information Grid */}
                {bookingMode === 'existing' ? (
                  <div className="space-y-2">
                    <label className="block text-xs uppercase font-mono tracking-wider font-bold text-slate-400">
                      Link Registered Profile
                    </label>
                    <div className="relative">
                      <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-slate-400" />
                      <select
                        value={selectedUserUid}
                        onChange={(e) => setSelectedUserUid(e.target.value)}
                        className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-50 font-medium text-slate-700 cursor-pointer bg-white"
                      >
                        <option value="">Choose clinical candidate...</option>
                        {allUsers.map((u) => (
                          <option key={u.userId} value={u.userId}>
                            {u.name} ({u.email || 'No Email'} — {u.phone || 'No Phone'})
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4 pt-3 border-t border-slate-100">
                    <span className="block text-[10px] uppercase font-mono tracking-widest text-slate-400 font-extrabold flex items-center gap-1">
                      <UserPlus className="w-4 h-4 text-emerald-500" /> Create Patient Directory Entry
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      {/* Name input */}
                      <div className="space-y-2">
                        <label className="block text-xxs font-bold text-slate-500 uppercase tracking-wide">Patient Legal Name</label>
                        <input
                          type="text"
                          placeholder="e.g. Richard Hendricks"
                          value={newPatientName}
                          onChange={(e) => setNewPatientName(e.target.value)}
                          className="w-full px-4 py-2.5 rounded-xl border border-slate-200 outline-none focus:border-emerald-500 text-xs"
                        />
                      </div>

                      {/* Phone input */}
                      <div className="space-y-2">
                        <label className="block text-xxs font-bold text-slate-500 uppercase tracking-wide">Patient Cellular</label>
                        <input
                          type="text"
                          placeholder="e.g. (555) 987-6543"
                          value={newPatientPhone}
                          onChange={(e) => setNewPatientPhone(e.target.value)}
                          className="w-full px-4 py-2.5 rounded-xl border border-slate-200 outline-none focus:border-emerald-500 text-xs"
                        />
                      </div>

                      {/* Email input */}
                      <div className="space-y-2">
                        <label className="block text-xxs font-bold text-slate-500 uppercase tracking-wide">Communication Email</label>
                        <input
                          type="email"
                          placeholder="e.g. richard@hooli.xyz"
                          value={newPatientEmail}
                          onChange={(e) => setNewPatientEmail(e.target.value)}
                          className="w-full px-4 py-2.5 rounded-xl border border-slate-200 outline-none focus:border-emerald-500 text-xs"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Physicians and Clinical Scheduling Details */}
                <div className="space-y-4 pt-4 border-t border-slate-100">
                  <span className="block text-[10px] uppercase font-mono tracking-widest text-slate-400 font-extrabold flex items-center gap-1">
                    <Stethoscope className="w-4 h-4 text-emerald-500" /> Physician Speciality Allocation
                  </span>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Department Drop */}
                    <div className="space-y-2">
                      <label className="block text-xxs font-bold text-slate-550 uppercase tracking-wide">Hospital Clinic Department</label>
                      <select
                        value={selectedDeptId}
                        onChange={(e) => {
                          setSelectedDeptId(e.target.value);
                          setSelectedDocIdInternal('');
                          setSelectedSlot('');
                        }}
                        className="w-full px-4 py-2.5 rounded-xl border border-slate-200 outline-none focus:border-emerald-500 cursor-pointer bg-white font-medium"
                      >
                        <option value="">Choose department...</option>
                        {DEPARTMENTS.map((dept) => (
                          <option key={dept.id} value={dept.id}>{dept.name}</option>
                        ))}
                      </select>
                    </div>

                    {/* Doctor drop */}
                    <div className="space-y-2">
                      <label className="block text-xxs font-bold text-slate-550 uppercase tracking-wide">Executive Physician Specialist</label>
                      <select
                        value={selectedDocIdInternal}
                        onChange={(e) => {
                          setSelectedDocIdInternal(e.target.value);
                          setSelectedSlot('');
                        }}
                        disabled={!selectedDeptId}
                        className="w-full px-4 py-2.5 rounded-xl border border-slate-200 outline-none focus:border-emerald-500 cursor-pointer disabled:bg-slate-50 disabled:text-slate-400 bg-white font-medium"
                      >
                        <option value="">{!selectedDeptId ? 'First pick department...' : 'Select physician...'}</option>
                        {formDoctors.map((doc) => (
                          <option key={doc.id} value={doc.id}>{doc.name} ({doc.role})</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {activeFormDoctor && (
                    <div className="p-3 bg-emerald-55 rounded-xl border border-emerald-100 text-[10px] text-slate-600">
                      <strong>Specialist Days:</strong> {activeFormDoctor.availability.days.join(', ')}
                    </div>
                  )}

                  {/* Calendar schedule and reservation hour */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Date select */}
                    <div className="space-y-2">
                      <label className="block text-xxs font-bold text-slate-550 uppercase tracking-wide">Consultation Date</label>
                      <input
                        type="date"
                        value={selectedDate}
                        disabled={!selectedDocIdInternal}
                        onChange={(e) => {
                          setSelectedDate(e.target.value);
                          setSelectedSlot('');
                        }}
                        min={new Date().toISOString().split('T')[0]}
                        className="w-full px-4 py-2.5 rounded-xl border border-slate-200 outline-none focus:border-emerald-500 bg-white cursor-pointer"
                      />
                    </div>

                    {/* Slot Hour Drop */}
                    <div className="space-y-2">
                      <label className="block text-xxs font-bold text-slate-550 uppercase tracking-wide">Lobby Hour Slot</label>
                      <select
                        value={selectedSlot}
                        onChange={(e) => setSelectedSlot(e.target.value)}
                        disabled={!selectedDate || !activeFormDoctor}
                        className="w-full px-4 py-2.5 rounded-xl border border-slate-200 outline-none focus:border-emerald-500 cursor-pointer disabled:bg-slate-50 bg-white"
                      >
                        <option value="">{!selectedDate ? 'Pick a date first...' : 'Select Slot...'}</option>
                        {activeFormDoctor?.availability.slots.map(slot => (
                          <option key={slot} value={slot}>{slot}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>

                {/* Health Symptoms Description */}
                <div className="space-y-2 pt-2 border-t border-slate-100">
                  <span className="block text-[10px] uppercase font-mono tracking-widest text-slate-400 font-extrabold">Symptoms / Clinical Directives</span>
                  <textarea
                    placeholder="Regular blood pressure readings, general patient concerns, symptoms for OPD checkup..."
                    value={symptoms}
                    onChange={(e) => setSymptoms(e.target.value)}
                    rows={2}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 outline-none focus:border-emerald-500 resize-none font-medium"
                  />
                </div>

                {/* Submitting Actions */}
                <div className="flex gap-4 pt-4 border-t border-slate-100">
                  <button
                    type="submit"
                    className="flex-grow py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold font-mono text-xs uppercase tracking-wider rounded-xl shadow-md cursor-pointer"
                  >
                    Confirm Consultation Ticket
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsAddingBooking(false)}
                    className="px-6 py-3 border border-slate-200 hover:bg-slate-100 text-slate-500 font-bold font-mono text-xs uppercase tracking-wider rounded-xl cursor-pointer"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
