import { useState } from 'react';
import { Hospital, Menu, X, CalendarCheck, HeartPulse, User, LogOut } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export default function Navbar({ activeTab, setActiveTab }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const { user, userProfile, signOutUser } = useAuth();

  const isAdmin = user && (user.email === 'jayeshpandit2505@gmail.com' || userProfile?.email === 'jayeshpandit2505@gmail.com');

  const navItems = [
    { name: 'Home', id: 'home' },
    { name: 'About', id: 'about' },
    { name: 'Departments', id: 'departments' },
    { name: 'Doctors', id: 'doctors' },
    ...(isAdmin ? [{ name: 'Admin Portal', id: 'admin' }] : []),
    { name: 'Booking', id: 'booking', highlight: true },
  ];

  const handleNavClick = (tabId: string) => {
    setActiveTab(tabId);
    setIsOpen(false);
  };

  return (
    <nav className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-slate-100 shadow-sm transition-all duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20">
          {/* Logo */}
          <div className="flex items-center gap-3 cursor-pointer group" onClick={() => handleNavClick('home')} id="nav-logo">
            <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-emerald-600 text-white shadow-md shadow-emerald-200 group-hover:bg-emerald-700 transition-all duration-300">
              <HeartPulse className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <span className="text-xl font-bold tracking-tight text-slate-800 font-sans leading-none flex items-center gap-1">
                WeCare <span className="text-emerald-600 font-black font-mono">Hospitals</span>
              </span>
              <span className="block text-xxs tracking-widest text-slate-400 font-mono uppercase font-bold mt-0.5">
                Care • Innovation • Excellence
              </span>
            </div>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-1 lg:space-x-2">
            {navItems.map((item) => {
              const isActive = activeTab === item.id;
              if (item.highlight) {
                return (
                  <button
                    key={item.id}
                    onClick={() => handleNavClick(item.id)}
                    id={`nav-item-${item.id}`}
                    className={`ml-4 px-5 py-2.5 rounded-xl font-medium text-sm flex items-center gap-2 transition-all duration-300 shadow-sm hover:shadow-md ${
                      isActive
                        ? 'bg-emerald-700 text-white shadow-emerald-200'
                        : 'bg-emerald-600 text-white hover:bg-emerald-700 hover:scale-[1.02] active:scale-[0.98]'
                    }`}
                  >
                    <CalendarCheck className="w-4 h-4" />
                    Book Appointment
                  </button>
                );
              }

              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  id={`nav-item-${item.id}`}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                    isActive
                      ? 'text-emerald-700 bg-emerald-50/70 font-semibold'
                      : 'text-slate-600 hover:text-emerald-600 hover:bg-slate-50'
                  }`}
                >
                  {item.name}
                </button>
              );
            })}

            {/* Logged in patient avatar badge / info */}
            {user && userProfile ? (
              <div className="ml-4 pl-4 border-l border-slate-100 flex items-center gap-3" id="nav-user-session">
                <div 
                  onClick={() => handleNavClick('booking')}
                  className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold text-xs font-mono border border-emerald-100/45 cursor-pointer hover:bg-emerald-100/50 transition-colors"
                  title="View Patient Dashboard"
                >
                  {userProfile.name.charAt(0).toUpperCase()}
                </div>
                <div className="text-left hidden lg:block">
                  <span className="block text-[10px] uppercase font-mono tracking-widest text-slate-400 font-bold leading-none">PATIENT ACTIVE</span>
                  <span className="text-slate-700 text-xs font-bold font-sans mt-0.5 block truncate max-w-[100px]">{userProfile.name}</span>
                </div>
                <button
                  onClick={() => {
                    signOutUser();
                    handleNavClick('home');
                  }}
                  id="nav-sign-out-btn"
                  className="p-1.5 text-slate-400 hover:text-red-500 rounded-lg hover:bg-slate-50 transition-colors cursor-pointer"
                  title="Log Out Access"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="ml-4 pl-4 border-l border-slate-100" id="nav-login-cta">
                <button
                  onClick={() => handleNavClick('booking')}
                  className="px-4 py-2 text-xs font-bold font-mono tracking-wide uppercase bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl transition-colors cursor-pointer"
                >
                  Sign In
                </button>
              </div>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="flex items-center md:hidden gap-3">
            {user && userProfile && (
              <div 
                onClick={() => handleNavClick('booking')}
                className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold text-xs cursor-pointer"
              >
                {userProfile.name.charAt(0).toUpperCase()}
              </div>
            )}
            <button
              onClick={() => setIsOpen(!isOpen)}
              id="mobile-menu-btn"
              className="inline-flex items-center justify-center p-2 rounded-lg text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 focus:outline-none transition-colors duration-200"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-white border-b border-slate-100 px-4 pt-2 pb-6 space-y-1 shadow-inner animate-in fade-in slide-in-from-top-4 duration-200">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            if (item.highlight) {
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  id={`mobile-nav-item-${item.id}`}
                  className="w-full mt-3 px-4 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-medium text-center flex items-center justify-center gap-2 transition-all duration-200 shadow-sm"
                >
                  <CalendarCheck className="w-4 h-4" />
                  Book Appointment
                </button>
              );
            }

            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                id={`mobile-nav-item-${item.id}`}
                className={`block w-full text-left px-4 py-3 rounded-lg text-base font-medium transition-all duration-200 ${
                  isActive
                    ? 'text-emerald-700 bg-emerald-50 font-semibold border-l-4 border-emerald-600 pl-3'
                    : 'text-slate-600 hover:text-emerald-600 hover:bg-slate-50'
                }`}
              >
                {item.name}
              </button>
            );
          })}

          {user && userProfile ? (
            <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between px-4 font-mono text-xs">
              <div>
                <span className="block text-[8px] uppercase tracking-wider text-slate-400 font-bold">Logged In As</span>
                <span className="text-slate-700 font-bold font-sans">{userProfile.name}</span>
              </div>
              <button
                onClick={() => { signOutUser(); setIsOpen(false); handleNavClick('home'); }}
                className="px-3 py-1.5 border border-red-200 hover:bg-red-50 text-red-600 rounded-lg font-bold font-mono text-xxs uppercase cursor-pointer"
              >
                Log Out
              </button>
            </div>
          ) : (
            <button
              onClick={() => handleNavClick('booking')}
              className="w-full mt-2 px-4 py-3 border border-slate-200 text-slate-600 hover:bg-slate-50 font-medium text-center rounded-xl text-sm transition-all cursor-pointer"
            >
              Sign In to Patient Portal
            </button>
          )}
        </div>
      )}
    </nav>
  );
}
