import { useState, FormEvent } from 'react';
import { useAuth } from '../context/AuthContext';
import { Mail, Lock, User, Phone, CheckCircle, ShieldAlert, Sparkles } from 'lucide-react';

interface AuthFormProps {
  onSuccess?: () => void;
}

export default function AuthForm({ onSuccess }: AuthFormProps) {
  const { signInWithEmail, signUpWithEmail, signInWithGoogle, error: authError } = useAuth();
  
  const [isSignUp, setIsSignUp] = useState(false);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [formError, setFormError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setFormError('');

    // Field validaton
    if (!email.trim()) return setFormError('Email address is requested.');
    if (!password) return setFormError('Password is requested.');
    if (password.length < 6) return setFormError('Password must be at least 6 characters.');
    
    if (isSignUp) {
      if (!name.trim()) return setFormError('Please specify your profile name.');
      if (!phone.trim()) return setFormError('Please specify cellular contact.');
    }

    setLoading(true);
    try {
      if (isSignUp) {
        await signUpWithEmail(email, password, name, phone);
      } else {
        await signInWithEmail(email, password);
      }
      if (onSuccess) onSuccess();
    } catch (err: any) {
      setFormError(err?.message || 'Authentication error. Please verify input fields.');
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setLoading(true);
    setFormError('');
    try {
      await signInWithGoogle();
      if (onSuccess) onSuccess();
    } catch (err: any) {
      setFormError(err?.message || 'Google Authentication failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full max-w-md mx-auto bg-white border border-slate-100 rounded-3xl p-6 sm:p-8 shadow-xl space-y-6" id="clinical-auth-form">
      {/* Header Accent Branding */}
      <div className="text-center space-y-2">
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 text-[10px] font-bold tracking-wider font-mono uppercase">
          <Sparkles className="w-3 h-3" /> Secure Health ID
        </span>
        <h2 className="text-2xl font-bold tracking-tight text-slate-800 font-sans">
          {isSignUp ? 'Create Patient Account' : 'Sign in to WeCare'}
        </h2>
        <p className="text-slate-400 text-xs">
          {isSignUp 
            ? 'Sign up to safely book appointments and synchronize preferences' 
            : 'Access your clinical records, booking schedule, and doctor recommendations'
          }
        </p>
        {!isSignUp && (
          <div className="bg-emerald-50 border border-emerald-100 rounded-xl p-3 text-left space-y-1 mt-2">
            <span className="block text-[9px] font-bold font-mono text-emerald-800 uppercase tracking-wider flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-emerald-650 animate-pulse" /> SYSTEM REGISTRAR ADMIN PORTAL
            </span>
            <div className="text-xxs font-mono text-slate-500 space-y-0.5">
              <div>Email: <span className="text-slate-800 font-extrabold">jayeshpandit2505@gmail.com</span></div>
              <div>Password: <span className="text-slate-800 font-extrabold">090909</span></div>
            </div>
          </div>
        )}
      </div>

      {/* Toggles */}
      <div className="flex bg-slate-50 p-1 rounded-xl">
        <button
          type="button"
          onClick={() => { setIsSignUp(false); setFormError(''); }}
          id="btn-toggle-login"
          className={`flex-1 py-2 text-xs font-bold font-mono uppercase rounded-lg transition-all ${
            !isSignUp 
              ? 'bg-white text-emerald-700 shadow-sm' 
              : 'text-slate-400 hover:text-slate-600'
          }`}
        >
          Sign In
        </button>
        <button
          type="button"
          onClick={() => { setIsSignUp(true); setFormError(''); }}
          id="btn-toggle-signup"
          className={`flex-1 py-2 text-xs font-bold font-mono uppercase rounded-lg transition-all ${
            isSignUp 
              ? 'bg-white text-emerald-700 shadow-sm' 
              : 'text-slate-400 hover:text-slate-600'
          }`}
        >
          Register
        </button>
      </div>

      {/* Errors output */}
      {(formError || authError) && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-2xl flex items-start gap-3 text-red-700 text-xs font-medium" id="auth-error-panel">
          <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5 text-red-600" />
          <div className="space-y-1">
            <span className="font-bold">Error Occurred:</span>
            <p className="opacity-90">{formError || authError}</p>
          </div>
        </div>
      )}

      {/* Input Action Forms */}
      <form onSubmit={handleSubmit} className="space-y-4">
        {isSignUp && (
          <>
            {/* Legal Name */}
            <div className="space-y-1.5">
              <label className="block text-xxs font-mono uppercase tracking-wider font-bold text-slate-500">Legal Full Name</label>
              <div className="relative">
                <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="John Doe"
                  value={name}
                  id="auth-input-name"
                  onChange={(e) => setName(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-50 text-sm transition-all text-slate-700 font-medium"
                />
              </div>
            </div>

            {/* Cellular phone */}
            <div className="space-y-1.5">
              <label className="block text-xxs font-mono uppercase tracking-wider font-bold text-slate-500">Cellular Contact Phone</label>
              <div className="relative">
                <Phone className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="tel"
                  placeholder="(555) 123-4567"
                  value={phone}
                  id="auth-input-phone"
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-50 text-sm transition-all text-slate-700 font-medium"
                />
              </div>
            </div>
          </>
        )}

        {/* Email */}
        <div className="space-y-1.5">
          <label className="block text-xxs font-mono uppercase tracking-wider font-bold text-slate-500">Email Address</label>
          <div className="relative">
            <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="email"
              placeholder="e.g. john@example.com"
              value={email}
              id="auth-input-email"
              onChange={(e) => setEmail(e.target.value)}
              className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-50 text-sm transition-all text-slate-700 font-medium"
            />
          </div>
        </div>

        {/* Password */}
        <div className="space-y-1.5">
          <label className="block text-xxs font-mono uppercase tracking-wider font-bold text-slate-500">Password Code</label>
          <div className="relative">
            <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="password"
              placeholder="••••••••"
              value={password}
              id="auth-input-password"
              onChange={(e) => setPassword(e.target.value)}
              className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-50 text-sm transition-all text-slate-700 font-medium"
            />
          </div>
        </div>

        {/* Action Button submit */}
        <button
          type="submit"
          disabled={loading}
          id="auth-form-submit-btn"
          className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-300 text-white font-bold text-xs rounded-xl tracking-wider uppercase transition-all shadow-md shadow-emerald-100 flex items-center justify-center gap-2 cursor-pointer"
        >
          {loading ? (
            <span className="w-4 h-4 border-2 border-white/25 border-t-white rounded-full animate-spin"></span>
          ) : (
            <>
              <CheckCircle className="w-4 h-4" />
              {isSignUp ? 'Create Health Card profile' : 'Sign In To Dashboard'}
            </>
          )}
        </button>
      </form>

      {/* Divider */}
      <div className="relative flex py-2 items-center">
        <div className="flex-grow border-t border-slate-100"></div>
        <span className="flex-shrink mx-4 text-slate-300 font-mono text-[9px] uppercase tracking-wider">Social Integrations</span>
        <div className="flex-grow border-t border-slate-100"></div>
      </div>

      {/* Google Sign in Button */}
      <button
        type="button"
        onClick={handleGoogleSignIn}
        disabled={loading}
        id="google-login-btn"
        className="w-full py-3 bg-white hover:bg-slate-50 border border-slate-200 text-slate-600 text-xs font-bold rounded-xl flex items-center justify-center gap-3 shadow-xs transition-colors cursor-pointer"
      >
        <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
          <path
            fill="#EA4335"
            d="M5.266 9.765A7.077 7.077 0 0 1 12 4.909c1.69 0 3.218.6 4.418 1.582l3.51-3.51C17.642 1.09 14.974 0 12 0 7.354 0 3.307 2.67 1.341 6.551l3.925 3.214z"
          />
          <path
            fill="#4285F4"
            d="M23.49 12.275c0-.825-.075-1.62-.213-2.385H12v4.515h6.442a5.505 5.505 0 0 1-2.385 3.615l3.71 2.872c2.173-2.002 3.723-4.943 3.723-8.617z"
          />
          <path
            fill="#FBBC05"
            d="M5.266 14.235L1.341 17.45A11.962 11.962 0 0 0 12 24c2.974 0 5.643-1.09 7.764-2.972l-3.71-2.873a7.11 7.11 0 0 1-4.054 1.136 7.073 7.073 0 0 1-6.734-4.856z"
          />
          <path
            fill="#34A853"
            d="M5.266 14.235A7.042 7.042 0 0 1 4.909 12c0-.795.12-1.56.357-2.235L1.341 6.55A11.97 11.97 0 0 0 0 12c0 2.012.5 3.905 1.341 5.45l3.925-3.215z"
          />
        </svg>
        <span>Access Securely with Google</span>
      </button>

      {/* Enabling Helper Note */}
      <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100/50 text-xxs text-slate-400 font-mono leading-normal text-center">
        <span>Note: Ensure <strong>Email/Password</strong> and <strong>Google Sign-in</strong> are enabled inside your Firebase Auth console panel.</span>
      </div>
    </div>
  );
}
