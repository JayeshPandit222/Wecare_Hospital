import { HeartPulse, Phone, Mail, MapPin, Clock, ShieldCheck } from 'lucide-react';

interface FooterProps {
  setActiveTab: (tab: string) => void;
}

export default function Footer({ setActiveTab }: FooterProps) {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-slate-900 text-slate-300 border-t border-slate-800" id="global-footer">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand Col */}
          <div className="space-y-4">
            <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab('home')}>
              <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-emerald-500 text-slate-900 shadow-lg shadow-emerald-500/20">
                <HeartPulse className="w-6 h-6" />
              </div>
              <span className="text-xl font-bold text-white tracking-tight">
                WeCare <span className="text-emerald-400 font-mono font-black">Hospitals</span>
              </span>
            </div>
            <p className="text-sm text-slate-400 leading-relaxed font-sans max-w-sm">
              Dedicated to clinical superiority, caring nurture, and top-tier technological integration. Transforming health services one smile at a time.
            </p>
            <div className="flex items-center gap-2 pt-2 text-xs font-mono text-slate-500">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Joint Commission Accredited Hospital</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-sm font-semibold text-white tracking-widest uppercase font-mono mb-6">
              Our Services
            </h3>
            <ul className="space-y-3.5 text-sm">
              {[
                { label: 'Cardiology Clinic', id: 'cardiology' },
                { label: 'Pediatric Care', id: 'pediatrics' },
                { label: 'Neurological Sciences', id: 'neurology' },
                { label: 'Orthopedic Orthopedics & Joints', id: 'orthopedics' },
                { label: 'Advanced Oncology Unit', id: 'oncology' }
              ].map((link, idx) => (
                <li key={idx}>
                  <button
                    onClick={() => setActiveTab('departments')}
                    className="text-slate-400 hover:text-emerald-400 transition-colors duration-200 text-left cursor-pointer"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Support Links */}
          <div>
            <h3 className="text-sm font-semibold text-white tracking-widest uppercase font-mono mb-6">
              Quick Resources
            </h3>
            <ul className="space-y-3.5 text-sm">
              {[
                { label: 'Home Page Dashboard', id: 'home' },
                { label: 'About Our Team & Vision', id: 'about' },
                { label: 'Search Medical Staff', id: 'doctors' },
                { label: 'Instant Booking Portal', id: 'booking' }
              ].map((link, idx) => (
                <li key={idx}>
                  <button
                    onClick={() => setActiveTab(link.id)}
                    className="text-slate-400 hover:text-emerald-400 transition-colors duration-200 text-left cursor-pointer"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Details */}
          <div>
            <h3 className="text-sm font-semibold text-white tracking-widest uppercase font-mono mb-6">
              Get in Touch
            </h3>
            <ul className="space-y-4 text-sm font-sans">
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <span className="text-slate-400">
                  101 Medical Center Drive, Golden Enclave, Sector-4, Metropolis
                </span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-emerald-400 shrink-0" />
                <div>
                  <span className="block text-slate-400 font-mono">+1 (800) 555-CARE</span>
                  <span className="block text-xxs text-red-400 font-semibold uppercase tracking-wider">
                    24/7 Emergency Helpline
                  </span>
                </div>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-emerald-400 shrink-0" />
                <span className="text-slate-400 font-mono">support@wecarehospitals.org</span>
              </li>
              <li className="flex items-start gap-3 pt-2 border-t border-slate-800/80">
                <Clock className="w-5 h-5 text-slate-500 shrink-0 mt-0.5" />
                <div className="text-xs text-slate-500">
                  <span className="block">Outpatient (OPD): 08:30 AM – 08:30 PM</span>
                  <span className="block">Inpatient & ICU visiting: See guidelines</span>
                </div>
              </li>
            </ul>
          </div>
        </div>

        {/* Lower Banner */}
        <div className="mt-12 pt-8 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500 font-mono">
          <p>© {currentYear} WeCare Hospitals Network. All Rights Reserved.</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-amber-400 transition-colors">Privacy Principles</a>
            <a href="#" className="hover:text-amber-400 transition-colors">Patient Bill of Rights</a>
            <a href="#" className="hover:text-amber-400 transition-colors">Interactive Sitemap</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
