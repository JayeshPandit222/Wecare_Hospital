import { useState, FormEvent, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { User, Phone, Mail, Clock, ShieldCheck, Edit, Save, ArrowRight } from 'lucide-react';

interface ProfileEditorProps {
  completedCount: number;
  savedDoctorsCount: number;
}

export default function ProfileEditor({ completedCount, savedDoctorsCount }: ProfileEditorProps) {
  const { user, userProfile, updateProfileData } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [loading, setLoading] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  // Hydrate fields
  useEffect(() => {
    if (userProfile) {
      setName(userProfile.name);
      setPhone(userProfile.phone || '');
    }
  }, [userProfile, isEditing]);

  const handleSave = async (e: FormEvent) => {
    e.preventDefault();
    setSuccessMsg('');
    setErrorMsg('');

    if (!name.trim()) {
      setErrorMsg('Profile name cannot be left blank.');
      return;
    }

    setLoading(true);
    try {
      await updateProfileData(name.trim(), phone.trim());
      setSuccessMsg('Your patient profile was saved successfully!');
      setIsEditing(false);
    } catch (err: any) {
      setErrorMsg(err?.message || 'Failed to update credentials. Please retry.');
    } finally {
      setLoading(false);
    }
  };

  if (!user || !userProfile) return null;

  return (
    <div className="bg-white border border-slate-100 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6" id="profile-editor-card">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 border-b border-slate-100 pb-5">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold text-lg font-mono">
            {userProfile.name.charAt(0).toUpperCase()}
          </div>
          <div className="space-y-0.5">
            <span className="block text-xxs font-mono font-bold uppercase tracking-wider text-emerald-600">CONFIRMED HEALTH PROFILE</span>
            <h3 className="text-lg font-bold text-slate-800 tracking-tight">{userProfile.name}</h3>
          </div>
        </div>

        {!isEditing ? (
          <button
            onClick={() => setIsEditing(true)}
            id="btn-edit-profile-trigger"
            className="px-4 py-2 text-xs font-bold font-mono tracking-wide uppercase bg-slate-100 text-slate-700 hover:bg-slate-200 transition-colors rounded-xl flex items-center gap-1.5 self-start cursor-pointer"
          >
            <Edit className="w-3.5 h-3.5" />
            Edit Profile
          </button>
        ) : null}
      </div>

      {/* Messages */}
      {successMsg && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-medium rounded-xl flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {errorMsg && (
        <div className="p-3.5 bg-red-50 border border-red-200 text-red-700 text-xs font-medium rounded-xl">
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Profile Metrics Summary Panel */}
      <div className="grid grid-cols-2 gap-4">
        <div className="p-4 bg-slate-50 border border-slate-100 rounded-2xl">
          <span className="block text-[10px] uppercase font-mono tracking-wider font-semibold text-slate-400">Scheduled Visits</span>
          <span className="text-2xl font-black font-mono text-slate-800 mt-1 block">{completedCount}</span>
        </div>
        <div className="p-4 bg-slate-50 border border-slate-100 rounded-2xl">
          <span className="block text-[10px] uppercase font-mono tracking-wider font-semibold text-slate-400">Saved Lookings</span>
          <span className="text-2xl font-black font-mono text-slate-800 mt-1 block">{savedDoctorsCount}</span>
        </div>
      </div>

      {/* Form Details */}
      <form onSubmit={handleSave} className="space-y-4">
        <div className="space-y-4">
          {/* User Full Name (Editable) */}
          <div className="space-y-2">
            <label className="block text-xs uppercase font-mono tracking-wider font-bold text-slate-400">Patient Full Name</label>
            <div className="relative">
              <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                disabled={!isEditing}
                value={name}
                id="profile-name-edit-input"
                onChange={(e) => setName(e.target.value)}
                placeholder="Legal Name"
                className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-50 text-sm transition-all bg-white disabled:bg-slate-50 disabled:text-slate-500 font-medium text-slate-700 font-sans"
              />
            </div>
          </div>

          {/* User Phone Number (Editable) */}
          <div className="space-y-2">
            <label className="block text-xs uppercase font-mono tracking-wider font-bold text-slate-400">Contact Number</label>
            <div className="relative">
              <Phone className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="tel"
                disabled={!isEditing}
                value={phone}
                id="profile-phone-edit-input"
                onChange={(e) => setPhone(e.target.value)}
                placeholder="Enter cellular number"
                className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-50 text-sm transition-all bg-white disabled:bg-slate-50 disabled:text-slate-500 font-medium text-slate-700 font-sans"
              />
            </div>
          </div>

          {/* User Email (Immutable) */}
          <div className="space-y-2">
            <label className="block text-xs uppercase font-mono tracking-wider font-bold text-slate-400">Communication Email</label>
            <div className="relative">
              <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-350" />
              <input
                type="email"
                disabled
                value={userProfile.email}
                id="profile-email-read-only"
                className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-100 outline-none text-sm bg-slate-50 text-slate-400 font-medium font-sans cursor-not-allowed"
              />
            </div>
            <p className="text-[10px] text-slate-400 font-mono">Linked login credentials cannot be swapped.</p>
          </div>
        </div>

        {/* Action button edit/save */}
        {isEditing && (
          <div className="flex gap-3 pt-2">
            <button
              type="submit"
              disabled={loading}
              id="btn-save-profile-action"
              className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs uppercase tracking-wide rounded-xl flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <Save className="w-4 h-4" />
              Save Credentials
            </button>
            <button
              type="button"
              id="btn-cancel-profile-edit"
              onClick={() => setIsEditing(false)}
              className="px-4 py-3 bg-slate-100 text-slate-600 hover:bg-slate-200 font-bold text-xs uppercase tracking-wide rounded-xl transition-colors cursor-pointer"
            >
              Cancel
            </button>
          </div>
        )}
      </form>
    </div>
  );
}
