import { motion } from 'motion/react';
import { 
  HeartPulse, 
  ArrowRight, 
  PhoneCall, 
  Award, 
  Activity, 
  Users, 
  ChevronRight, 
  ShieldCheck, 
  Sparkles, 
  ActivitySquare,
  Clock,
  Volume2,
  CalendarDays,
  Utensils,
  Star
} from 'lucide-react';
import { TESTIMONIALS } from '../data';

interface HomeSectionProps {
  setActiveTab: (tab: string) => void;
  setSelectedDepartmentId: (deptId: string | null) => void;
}

export default function HomeSection({ setActiveTab, setSelectedDepartmentId }: HomeSectionProps) {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { duration: 0.5, ease: 'easeOut' } }
  };

  return (
    <div className="space-y-20 pb-20 overflow-hidden" id="home-section">
      {/* Hero Banner Section */}
      <section className="relative bg-gradient-to-br from-slate-50 via-emerald-50/20 to-teal-50/10 py-16 lg:py-24">
        {/* Background Decorative Blobs */}
        <div className="absolute top-1/2 left-0 w-72 h-72 bg-emerald-400/10 rounded-full blur-3xl -translate-y-1/2 pointer-events-none" />
        <div className="absolute top-10 right-10 w-96 h-96 bg-teal-400/10 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Hero Left Content */}
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-100/80 text-emerald-800 text-xs font-mono font-bold tracking-wider uppercase border border-emerald-200 shadow-sm">
                <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                <span>Next-Gen Healthcare Technology</span>
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-sans font-bold tracking-tight text-slate-800 leading-tight">
                Your Health is Our <br />
                <span className="text-emerald-600 relative inline-block">
                  Sacred Priority
                  <svg className="absolute left-0 -bottom-2 w-full h-2 text-emerald-300 pointer-events-none" viewBox="0 0 100 10" preserveAspectRatio="none">
                    <path d="M0,5 Q50,10 100,5" stroke="currentColor" strokeWidth="4" fill="none" />
                  </svg>
                </span>
              </h1>

              <p className="text-lg text-slate-600 font-sans leading-relaxed max-w-xl">
                Experience world-class hospitality, highly accredited sub-specialists, and diagnostic infrastructure engineered for precise, patient-first clinical outcomes.
              </p>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-4">
                <button
                  onClick={() => setActiveTab('booking')}
                  id="hero-book-btn"
                  className="px-8 py-4 rounded-xl font-semibold text-white bg-emerald-600 hover:bg-emerald-700 transition-all duration-300 shadow-lg shadow-emerald-200 text-center flex items-center justify-center gap-2 group cursor-pointer"
                >
                  Book Instant Appointment
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-1.5 transition-transform duration-300" />
                </button>

                <button
                  onClick={() => setActiveTab('departments')}
                  id="hero-departments-btn"
                  className="px-8 py-4 rounded-xl font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 transition-all duration-300 text-center shadow-sm cursor-pointer"
                >
                  Our Specialized Clinics
                </button>
              </div>

              {/* Value Tags */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 pt-6 text-sm text-slate-500 font-medium">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-emerald-500" />
                  <span>JCI Accredited</span>
                </div>
                <div className="flex items-center gap-2">
                  <Users className="w-5 h-5 text-emerald-500" />
                  <span>50+ Top Specialists</span>
                </div>
                <div className="flex items-center gap-2 col-span-2 sm:col-span-1">
                  <Clock className="w-5 h-5 text-emerald-500" />
                  <span>24/7 Trauma Emergency</span>
                </div>
              </div>
            </div>

            {/* Hero Right Visual Column */}
            <div className="lg:col-span-5 relative">
              <div className="relative mx-auto max-w-md lg:max-w-none">
                {/* Visual Accent Box */}
                <div className="absolute -inset-2 bg-gradient-to-tr from-emerald-600 to-teal-500 rounded-3xl blur-md opacity-20 pointer-events-none" />
                
                {/* Main Hero Doctor Image */}
                <div className="relative bg-white border border-slate-100 p-3 rounded-3xl shadow-2xl overflow-hidden aspect-square flex items-center justify-center">
                  <img 
                    src="https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&q=80&w=800" 
                    alt="WeCare Hospital Clinical Care Team" 
                    referrerPolicy="no-referrer"
                    className="object-cover w-full h-full rounded-2xl grayscale-[15%] hover:grayscale-0 transition-all duration-500"
                  />
                  
                  {/* Floating Action Overlay */}
                  <div className="absolute bottom-6 left-6 right-6 bg-slate-900/90 backdrop-blur-md rounded-2xl p-4 text-white border border-white/10 shadow-xl flex items-center justify-between">
                    <div>
                      <span className="block text-xxs tracking-wider text-emerald-400 font-mono font-bold uppercase">Emergency Inbound</span>
                      <span className="block font-bold text-sm tracking-tight pt-0.5">Metropolis Trauma Dispatch</span>
                    </div>
                    <a 
                      href="tel:+18005552273"
                      className="px-4 py-2 rounded-xl bg-emerald-500 text-slate-900 font-bold font-mono text-xs flex items-center gap-1.5 hover:bg-emerald-400 transition-colors"
                    >
                      <PhoneCall className="w-3.5 h-3.5" />
                      CALL 24/7
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Trust Statistics / Highlights Ribbon */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white border border-slate-100 rounded-3xl p-8 shadow-sm">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 divide-x divide-slate-100">
            <div className="text-center p-2">
              <span className="block text-3xl sm:text-4xl font-extrabold text-slate-800 font-mono">99.2%</span>
              <span className="block text-xs text-slate-400 font-semibold tracking-wider uppercase mt-1">Cardiac Success</span>
            </div>
            <div className="text-center p-2 pl-4">
              <span className="block text-3xl sm:text-4xl font-extrabold text-slate-800 font-mono">15k+</span>
              <span className="block text-xs text-slate-400 font-semibold tracking-wider uppercase mt-1">Happy Inpatients</span>
            </div>
            <div className="text-center p-2 pl-4">
              <span className="block text-3xl sm:text-4xl font-extrabold text-slate-800 font-mono">250+</span>
              <span className="block text-xs text-slate-400 font-semibold tracking-wider uppercase mt-1">Accredited Beds</span>
            </div>
            <div className="text-center p-2 pl-4">
              <span className="block text-3xl sm:text-4xl font-extrabold text-slate-800 font-mono">15 Min</span>
              <span className="block text-xs text-slate-400 font-semibold tracking-wider uppercase mt-1">Avg OPD Intake</span>
            </div>
          </div>
        </div>
      </section>

      {/* Core Specialties / Clinical Strengths */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div className="text-center space-y-4 max-w-xl mx-auto">
          <span className="text-xs font-mono font-bold uppercase tracking-widest text-emerald-600">Our Services</span>
          <h2 className="text-3xl font-bold text-slate-800 font-sans tracking-tight">
            Specialized Care Centers
          </h2>
          <p className="text-slate-500 text-sm">
            Our clinics are staffed by board-certified department heads and utilize peer-reviewed diagnostic systems to support rapid physical rehabilitation.
          </p>
        </div>

        <motion.div 
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-100px' }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {[
            {
              title: 'Cardiovascular Care',
              desc: 'Advanced robotic bypass surgeries and real-time arrhythmia mapping.',
              color: 'from-blue-500 to-indigo-500',
              deptId: 'cardiology',
              icon: HeartPulse
            },
            {
              title: 'Pediatrics Wellness',
              desc: 'Committed to pleasant, painless outpatient sessions for kids.',
              color: 'from-emerald-500 to-teal-500',
              deptId: 'pediatrics',
              icon: Users
            },
            {
              title: 'Neurology Sciences',
              desc: 'Pioneering treatment designs for chronic migraine and brain tumors.',
              color: 'from-cyan-500 to-blue-500',
              deptId: 'neurology',
              icon: ActivitySquare
            },
            {
              title: 'Orthopedics & Spine',
              desc: 'Restoring absolute structural confidence with Joint replacements.',
              color: 'from-orange-500 to-amber-500',
              deptId: 'orthopedics',
              icon: Activity
            },
            {
              title: 'Oncology Therapies',
              desc: 'Leveraging targeted monoclonal antibodies and clinical trials.',
              color: 'from-rose-500 to-pink-500',
              deptId: 'oncology',
              icon: ShieldCheck
            }
          ].map((item, idx) => (
            <motion.div
              key={idx}
              variants={itemVariants}
              whileHover={{ y: -6, transition: { duration: 0.2 } }}
              className="group bg-white border border-slate-100 rounded-2xl p-6 shadow-sm hover:shadow-md transition-all duration-300 flex flex-col justify-between"
            >
              <div className="space-y-4">
                <div className="w-12 h-12 rounded-xl bg-slate-50 flex items-center justify-center text-emerald-600 group-hover:bg-emerald-600 group-hover:text-white transition-all duration-300">
                  <item.icon className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-slate-800 tracking-tight">{item.title}</h3>
                <p className="text-sm text-slate-500 leading-relaxed">{item.desc}</p>
              </div>

              <div className="pt-6 mt-4 border-t border-slate-50 flex items-center justify-between">
                <button
                  onClick={() => {
                    setSelectedDepartmentId(item.deptId);
                    setActiveTab('departments');
                  }}
                  className="text-emerald-600 hover:text-emerald-700 font-bold text-xs font-mono tracking-wider flex items-center gap-1 group-hover:gap-2 transition-all"
                >
                  VIEW CLINIC
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </section>

      {/* Call to action section: Highlight of outstanding facilities */}
      <section className="bg-slate-900 py-16 text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <span className="text-xs font-mono font-bold tracking-widest text-emerald-400 uppercase">Emergency Support Line</span>
              <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-white font-sans leading-tight">
                Get Expert Diagnosis & Clinical Counsel Within Minutes
              </h2>
              <p className="text-slate-300 text-sm leading-relaxed">
                Connect directly with our outpatient reservation line or use the fast-track online system. We ensure zero booking friction, automatic validation with your dynamic medical insurance card, and instantaneous scheduler reservation.
              </p>
              
              <div className="flex flex-wrap gap-4 pt-2">
                <button
                  onClick={() => setActiveTab('booking')}
                  className="px-6 py-3.5 rounded-xl bg-emerald-500 text-slate-900 font-bold text-sm tracking-tight hover:bg-emerald-400 transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <CalendarDays className="w-4 h-4" />
                  Reserve A Slot Instantly
                </button>
                <a
                  href="tel:+18005552273"
                  className="px-6 py-3.5 rounded-xl bg-transparent text-white border border-slate-700 hover:border-slate-500 font-bold text-sm tracking-tight transition-all flex items-center gap-1.5"
                >
                  <PhoneCall className="w-4 h-4 text-emerald-400" />
                  +1 (800) 555-CARE
                </a>
              </div>
            </div>

            {/* Quick Informational Accents Checklist */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {[
                { title: 'Zero Intake Wait', body: 'Patients with active digital appointments bypass lobby lines for targeted examinations.' },
                { title: 'Integrated Pharmacy', body: 'Collect all required medications seamlessly at our in-house smart dispensary.' },
                { title: 'Advanced Lab Tech', body: 'Biochemistry panels and high-slice MRI scans processed inside 2 hours.' },
                { title: 'Post-Op Monitoring', body: '24/7 dedicated sub-staff supervision for every surgical recovery suite.' }
              ].map((accent, idx) => (
                <div key={idx} className="bg-slate-800/60 border border-slate-800 p-5 rounded-2xl space-y-2">
                  <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center font-bold text-xs font-mono">
                    0{idx + 1}
                  </div>
                  <h4 className="text-white font-bold text-sm">{accent.title}</h4>
                  <p className="text-xs text-slate-400 leading-relaxed">{accent.body}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Patient Testimonials */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div className="text-center space-y-4 max-w-xl mx-auto">
          <span className="text-xs font-mono font-bold uppercase tracking-widest text-emerald-600">Praise From Hearts</span>
          <h2 className="text-3xl font-bold text-slate-800 font-sans tracking-tight">
            Loved by Our Patients
          </h2>
          <p className="text-slate-500 text-sm">
            Read stories of recovery, dedication, and precision diagnostics from patients who experienced WeCare Hospitals firsthand.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {TESTIMONIALS.map((t) => (
            <div key={t.id} className="bg-white border border-slate-100 rounded-3xl p-8 shadow-sm hover:shadow-md transition-all duration-300 relative flex flex-col justify-between">
              <div className="space-y-4">
                {/* Stars */}
                <div className="flex text-amber-400 gap-1">
                  {[...Array(t.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-current" />
                  ))}
                </div>
                <p className="text-slate-600 text-sm italic leading-relaxed">
                  "{t.text}"
                </p>
              </div>

              <div className="flex items-center justify-between pt-6 mt-6 border-t border-slate-50">
                <div>
                  <span className="block font-bold text-slate-800 text-sm">{t.name}</span>
                  <span className="block text-slate-400 text-xs font-medium">{t.relation}, Age {t.age}</span>
                </div>
                <span className="px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 text-xxs font-mono font-bold uppercase">
                  {t.department}
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
