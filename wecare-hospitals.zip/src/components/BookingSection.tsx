import { useState, useEffect, useMemo, FormEvent } from 'react';
import { DOCTORS, DEPARTMENTS } from '../data';
import { Appointment, Doctor } from '../types';
import { 
  Calendar, 
  Clock, 
  Stethoscope, 
  User, 
  Mail, 
  Phone, 
  FileText, 
  CheckCircle, 
  Trash2, 
  AlertCircle, 
  CalendarDays,
  Sparkles,
  ShieldCheck,
  Building2,
  CalendarCheck,
  Heart,
  LogOut,
  Sliders,
  Bookmark
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { collection, doc, query, onSnapshot, setDoc, deleteDoc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { motion, AnimatePresence } from 'motion/react';
import AuthForm from './AuthForm';
import ProfileEditor from './ProfileEditor';

interface BookingSectionProps {
  selectedDoctorId: string | null;
  setSelectedDoctorId: (docId: string | null) => void;
}

export default function BookingSection({
  selectedDoctorId,
  setSelectedDoctorId
}: BookingSectionProps) {
  const { user, userProfile, signOutUser } = useAuth();

  // Firestore collections states
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [lookings, setLookings] = useState<any[]>([]);
  const [activeSideTab, setActiveSideTab] = useState<'appointments' | 'lookings' | 'profile'>('appointments');

  // Form state
  const [selectedDeptId, setSelectedDeptId] = useState('');
  const [selectedDocIdInternal, setSelectedDocIdInternal] = useState('');
  const [patientName, setPatientName] = useState('');
  const [patientEmail, setPatientEmail] = useState('');
  const [patientPhone, setPatientPhone] = useState('');
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedSlot, setSelectedSlot] = useState('');
  const [symptoms, setSymptoms] = useState('');

  // Form error & success states
  const [formError, setFormError] = useState('');
  const [successBooking, setSuccessBooking] = useState<Appointment | null>(null);

  // Pre-fill fields with Patient Profile Data
  useEffect(() => {
    if (userProfile) {
      setPatientName(userProfile.name || '');
      setPatientEmail(userProfile.email || '');
      setPatientPhone(userProfile.phone || '');
    }
  }, [userProfile]);

  // Sync state changes from parent context (e.g. from Doctors tab quick-book)
  useEffect(() => {
    if (selectedDoctorId) {
      const docItem = DOCTORS.find(d => d.id === selectedDoctorId);
      if (docItem) {
        setSelectedDeptId(docItem.departmentId);
        setSelectedDocIdInternal(docItem.id);
        setSelectedDate('');
        setSelectedSlot('');
      }
    }
  }, [selectedDoctorId]);

  // Real-time listener for user appointments from Firestore
  useEffect(() => {
    if (!user) return;

    const path = `users/${user.uid}/appointments`;
    const q = query(collection(db, path));

    const unsubscribe = onSnapshot(q, (snapshot) => {
      try {
        const loaded: Appointment[] = snapshot.docs.map(docSnap => {
          const data = docSnap.data();
          // Convert firestore timestamp elegantly back to ISO strings
          return {
            id: docSnap.id,
            doctorId: data.doctorId,
            doctorName: data.doctorName,
            departmentId: data.departmentId,
            departmentName: data.departmentName,
            patientName: data.patientName,
            patientEmail: data.patientEmail,
            patientPhone: data.patientPhone,
            date: data.date,
            timeSlot: data.timeSlot,
            symptoms: data.symptoms,
            status: data.status,
            createdAt: data.createdAt ? (data.createdAt.toDate ? data.createdAt.toDate().toISOString() : data.createdAt) : new Date().toISOString()
          } as Appointment;
        });

        // Filter and sort by date descending
        loaded.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
        setAppointments(loaded);
      } catch (err) {
        handleFirestoreError(err, OperationType.GET, path);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, path);
    });

    return () => unsubscribe();
  }, [user]);

  // Real-time listener for lookings/saved doctors from Firestore
  useEffect(() => {
    if (!user) return;

    const path = `users/${user.uid}/lookings`;
    const q = query(collection(db, path));

    const unsubscribe = onSnapshot(q, (snapshot) => {
      try {
        const loaded = snapshot.docs.map(docSnap => ({
          id: docSnap.id,
          ...docSnap.data()
        }));
        setLookings(loaded);
      } catch (err) {
        handleFirestoreError(err, OperationType.GET, path);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, path);
    });

    return () => unsubscribe();
  }, [user]);

  // Handle department change internally
  const handleDeptChange = (deptId: string) => {
    setSelectedDeptId(deptId);
    setSelectedDocIdInternal('');
    setSelectedDate('');
    setSelectedSlot('');
    setFormError('');
    setSelectedDoctorId(null);
  };

  // Handle doctor change internally
  const handleDocChange = (docId: string) => {
    setSelectedDocIdInternal(docId);
    setSelectedDate('');
    setSelectedSlot('');
    setFormError('');
    setSelectedDoctorId(docId);
  };

  // List of doctors filtered by active department choice
  const filteredDoctors = useMemo(() => {
    if (!selectedDeptId) return [];
    return DOCTORS.filter(d => d.departmentId === selectedDeptId);
  }, [selectedDeptId]);

  // Single active doctor profile
  const activeDoctor = useMemo(() => {
    return DOCTORS.find(d => d.id === selectedDocIdInternal);
  }, [selectedDocIdInternal]);

  // Handle slot reservation click
  const handleBookingSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!user) return;

    // Validation
    if (!selectedDeptId) return setFormError('Please select a hospital department.');
    if (!selectedDocIdInternal) return setFormError('Please select an executive physician.');
    if (!selectedDate) return setFormError('Please select a comfortable consultation date.');
    if (!selectedSlot) return setFormError('Please choose an available hour slot.');
    if (!patientName.trim()) return setFormError('Please specify patient legal name.');
    if (!patientEmail.trim()) return setFormError('Please input a communication email address.');
    if (!patientPhone.trim()) return setFormError('Please provide a cellular contact phone.');

    const activeDept = DEPARTMENTS.find(d => d.id === selectedDeptId);
    const activeDoc = DOCTORS.find(d => d.id === selectedDocIdInternal);

    const newAptId = `apt-${Math.random().toString(36).substr(2, 9)}`;
    const path = `users/${user.uid}/appointments`;

    const appointmentPayload = {
      id: newAptId,
      userId: user.uid,
      doctorId: selectedDocIdInternal,
      doctorName: activeDoc?.name || 'Practitioner',
      departmentId: selectedDeptId,
      departmentName: activeDept?.name || 'General Outpatient',
      patientName: patientName.trim(),
      patientEmail: patientEmail.trim(),
      patientPhone: patientPhone.trim(),
      date: selectedDate,
      timeSlot: selectedSlot,
      symptoms: symptoms.trim() || 'General regular checkup.',
      status: 'Scheduled',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    };

    try {
      await setDoc(doc(db, path, newAptId), appointmentPayload);
      
      // Simulate presenting success booking locally with ISO string format fallback
      setSuccessBooking({
        ...appointmentPayload,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      } as Appointment);

      // Reset mutable forms
      setSelectedDate('');
      setSelectedSlot('');
      setSymptoms('');
      setSelectedDoctorId(null);
    } catch (err) {
      try {
        handleFirestoreError(err, OperationType.CREATE, `${path}/${newAptId}`);
      } catch (formattedErr: any) {
        setFormError(formattedErr.message);
      }
    }
  };

  const handleCancelAppointment = async (id: string) => {
    if (!user) return;
    if (confirm('Are you certain you wish to cancel this scheduled consultation?')) {
      const path = `users/${user.uid}/appointments/${id}`;
      try {
        await deleteDoc(doc(db, `users/${user.uid}/appointments`, id));
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, path);
      }
    }
  };

  const handleRemoveLooking = async (id: string) => {
    if (!user) return;
    const path = `users/${user.uid}/lookings/${id}`;
    try {
      await deleteDoc(doc(db, `users/${user.uid}/lookings`, id));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, path);
    }
  };

  // Login view state if not authenticated
  if (!user) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-20" id="booking-section-unauthenticated">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Welcome Intro Banner */}
          <div className="lg:col-span-6 space-y-6">
            <span className="text-xs font-mono font-bold uppercase tracking-widest text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full">
              WECARE CLINIC HUB
            </span>
            <h1 className="text-4xl sm:text-5xl font-extrabold text-slate-800 tracking-tight leading-tight">
              One Secure Account, <br />
              <span className="text-emerald-600">Total Health Harmony.</span>
            </h1>
            <p className="text-slate-500 text-base leading-relaxed max-w-lg">
              Unlock our medical scheduling ecosystem. Sign up for a Secure Patient Portfolio to instantly book physical slots with custom doctors, save specialists, and access care history.
            </p>

            <div className="space-y-4 pt-2">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold text-sm">✓</div>
                <span className="text-slate-700 font-medium text-sm">Save preferred practitioners ("My Lookings")</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold text-sm">✓</div>
                <span className="text-slate-700 font-medium text-sm">Manage dynamic lobby consultation tickets</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold text-sm">✓</div>
                <span className="text-slate-700 font-medium text-sm">Seamless HIPAA-compliant data storage</span>
              </div>
            </div>
          </div>

          <div className="lg:col-span-6">
            <AuthForm />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20 space-y-12" id="booking-section">
      {/* Header and User greeting banner */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 pt-6 pb-2 border-b border-slate-100">
        <div className="space-y-2">
          <span className="text-xs font-mono font-bold uppercase tracking-widest text-emerald-600">SCHEDULE PORTAL</span>
          <h1 className="text-3xl font-bold text-slate-800 font-sans tracking-tight">
            Consultation Scheduling Portal
          </h1>
          <p className="text-slate-500 text-sm">
            Active session: <span className="text-slate-700 font-semibold">{userProfile?.name}</span> ({userProfile?.email})
          </p>
        </div>

        {/* Quick logout */}
        <button
          onClick={signOutUser}
          id="btn-logout-portal"
          className="px-4 py-2 text-xs font-bold font-mono uppercase border border-slate-200 hover:bg-slate-50 text-slate-600 rounded-xl flex items-center gap-2 self-start cursor-pointer"
        >
          <LogOut className="w-4 h-4" />
          Log Out
        </button>
      </div>

      {/* Main Layout Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
        
        {/* Reservation Form OR Booking Success container */}
        {successBooking ? (
          <div className="lg:col-span-7 bg-white border-2 border-emerald-500 rounded-3xl p-8 shadow-xl relative overflow-hidden animate-in fade-in zoom-in-95 duration-200" id="booking-success-container">
            <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-100 rounded-bl-full flex items-center justify-center p-4">
              <CheckCircle className="w-12 h-12 text-emerald-600 animate-bounce" />
            </div>

            <div className="space-y-6">
              <div className="space-y-2">
                <span className="text-xs font-mono font-bold tracking-widest text-emerald-600 uppercase">REGISTRATION SUCCESSFUL</span>
                <h3 className="text-2xl font-bold text-slate-800 font-sans font-medium">Slot Reserved Successfully!</h3>
                <p className="text-slate-500 text-sm">
                  We have added your appointment to our clinical calendar queue. You can check its state in "My Lobby Registrations" below.
                </p>
              </div>

              {/* Patient Token Card Panel */}
              <div className="bg-slate-50 rounded-2xl p-6 border border-slate-100 space-y-4 font-sans text-sm">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <span className="block text-[10px] uppercase font-mono text-slate-400 font-semibold tracking-wider">APPOINTMENT ID</span>
                    <span className="font-bold text-slate-800 font-mono">{successBooking.id}</span>
                  </div>
                  <div>
                    <span className="block text-[10px] uppercase font-mono text-slate-400 font-semibold tracking-wider">LOBBY TOKEN</span>
                    <span className="font-bold text-emerald-700 font-mono">OPD-{Math.floor(100 + Math.random() * 900)}</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-100">
                  <div>
                    <span className="block text-[10px] uppercase font-mono text-slate-400 font-semibold tracking-wider">PHYSICIAN</span>
                    <span className="font-bold text-slate-800">{successBooking.doctorName}</span>
                  </div>
                  <div>
                    <span className="block text-[10px] uppercase font-mono text-slate-400 font-semibold tracking-wider">CLINIC</span>
                    <span className="font-bold text-slate-800">{successBooking.departmentName}</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-100">
                  <div>
                    <span className="block text-[10px] uppercase font-mono text-slate-400 font-semibold tracking-wider">DATE</span>
                    <span className="font-bold text-slate-800">{successBooking.date}</span>
                  </div>
                  <div>
                    <span className="block text-[10px] uppercase font-mono text-slate-400 font-semibold tracking-wider">TIME HOUR</span>
                    <span className="font-bold text-slate-800">{successBooking.timeSlot}</span>
                  </div>
                </div>
              </div>

              <div className="flex gap-4">
                <button
                  onClick={() => setSuccessBooking(null)}
                  className="px-6 py-3 bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs rounded-xl tracking-wide uppercase transition-colors shadow-sm cursor-pointer"
                >
                  Book Another Session
                </button>
              </div>
            </div>
          </div>
        ) : (
          /* Main Interactive Reservation Form */
          <div className="lg:col-span-7 bg-white border border-slate-100 rounded-3xl p-6 sm:p-8 shadow-sm">
            <h3 className="text-lg font-bold text-slate-800 tracking-tight font-sans border-b border-slate-100 pb-4 mb-6">
              Select Consultation Preferences
            </h3>

            {formError && (
              <div className="mb-6 p-4 rounded-xl bg-red-50 border border-red-200 flex items-center gap-3 text-red-700 text-xs font-medium" id="booking-error-panel">
                <AlertCircle className="w-5 h-5 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleBookingSubmit} className="space-y-6">
              {/* Step 1: Selection Dropdowns */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {/* Department drop */}
                <div className="space-y-2">
                  <label className="block text-xs uppercase font-mono tracking-wider font-bold text-slate-500">
                    Hospital Department
                  </label>
                  <div className="relative">
                    <Stethoscope className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <select
                      id="form-dept-select"
                      value={selectedDeptId}
                      onChange={(e) => handleDeptChange(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-55 text-sm transition-all bg-white font-medium text-slate-700 cursor-pointer"
                    >
                      <option value="">Select Department...</option>
                      {DEPARTMENTS.map((dept) => (
                        <option key={dept.id} value={dept.id}>
                          {dept.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Doctor drop */}
                <div className="space-y-2">
                  <label className="block text-xs uppercase font-mono tracking-wider font-bold text-slate-500">
                    Consulting Doctor
                  </label>
                  <div className="relative">
                    <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <select
                      id="form-doc-select"
                      value={selectedDocIdInternal}
                      onChange={(e) => handleDocChange(e.target.value)}
                      disabled={!selectedDeptId}
                      className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-50 text-sm transition-all bg-white disabled:bg-slate-50 disabled:text-slate-400 font-medium text-slate-700 cursor-pointer"
                    >
                      <option value="">
                        {!selectedDeptId ? 'First pick department...' : 'Select physician...'}
                      </option>
                      {filteredDoctors.map((doc) => (
                        <option key={doc.id} value={doc.id}>
                          {doc.name} ({doc.role})
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* Optional Active Doctor Lobby Highlights Banner */}
              {activeDoctor && (
                <div className="p-4 bg-emerald-50/50 rounded-2xl border border-emerald-100/50 space-y-2 text-xs">
                  <span className="font-bold text-emerald-800 block uppercase font-mono text-[10px] tracking-wider">
                    Physician Practice Availability Profile
                  </span>
                  <p className="text-slate-600 leading-normal">
                    <strong>{activeDoctor.name}</strong> is available on <strong>{activeDoctor.availability.days.join(', ')}</strong>. Consultation hours involve precise timeslot bookings.
                  </p>
                </div>
              )}

              {/* Step 2: Date Selector */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="block text-xs uppercase font-mono tracking-wider font-bold text-slate-500">
                    Consultation Date
                  </label>
                  <div className="relative">
                    <Calendar className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input
                      type="date"
                      value={selectedDate}
                      id="form-date-input"
                      disabled={!selectedDocIdInternal}
                      onChange={(e) => {
                        setSelectedDate(e.target.value);
                        setSelectedSlot('');
                      }}
                      min={new Date().toISOString().split('T')[0]}
                      className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-50 text-sm transition-all bg-white disabled:bg-slate-50 disabled:text-slate-400 font-medium text-slate-700 cursor-pointer"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="block text-xs uppercase font-mono tracking-wider font-bold text-slate-500">
                    Available Lobby Slot Hour
                  </label>
                  <div className="relative">
                    <Clock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <select
                      id="form-slot-select"
                      value={selectedSlot}
                      disabled={!selectedDate || !activeDoctor}
                      onChange={(e) => setSelectedSlot(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-50 text-sm transition-all bg-white disabled:bg-slate-50 disabled:text-slate-400 font-medium text-slate-700 cursor-pointer"
                    >
                      <option value="">
                        {!selectedDate ? 'Pick a date first...' : 'Select Slot...'}
                      </option>
                      {activeDoctor?.availability.slots.map(slot => (
                        <option key={slot} value={slot}>{slot}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* Step 4: Patient details (Synchronized with profile) */}
              <div className="space-y-4 pt-4 border-t border-slate-100">
                <span className="block text-xs uppercase font-mono tracking-widest text-slate-400 font-extrabold flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-500" /> Patient Legal Contact Info
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                  {/* Patient Legal Name */}
                  <div className="space-y-2">
                    <label className="block text-xs font-medium text-slate-600">Patient Full Name</label>
                    <div className="relative">
                      <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input
                        type="text"
                        placeholder="John Doe"
                        value={patientName}
                        id="form-patient-name"
                        onChange={(e) => setPatientName(e.target.value)}
                        className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-50 text-sm transition-all"
                      />
                    </div>
                  </div>

                  {/* Patient email */}
                  <div className="space-y-2">
                    <label className="block text-xs font-medium text-slate-600">Email Address</label>
                    <div className="relative">
                      <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input
                        type="email"
                        placeholder="john@example.com"
                        value={patientEmail}
                        id="form-patient-email"
                        onChange={(e) => setPatientEmail(e.target.value)}
                        className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-50 text-sm transition-all"
                      />
                    </div>
                  </div>

                  {/* Patient phone */}
                  <div className="space-y-2">
                    <label className="block text-xs font-medium text-slate-600">Cellular Contact</label>
                    <div className="relative">
                      <Phone className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input
                        type="tel"
                        placeholder="(555) 123-4567"
                        value={patientPhone}
                        id="form-patient-phone"
                        onChange={(e) => setPatientPhone(e.target.value)}
                        className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-50 text-sm transition-all"
                      />
                    </div>
                  </div>
                </div>

                {/* Patient Symptoms */}
                <div className="space-y-2 pt-2">
                  <label className="block text-xs font-medium text-slate-600">Brief Symptoms Description</label>
                  <div className="relative">
                    <FileText className="absolute left-3.5 top-3.5 w-4 h-4 text-slate-400" />
                    <textarea
                      placeholder="e.g. Regular high arterial readings, muscle strains, general health checkup..."
                      value={symptoms}
                      id="form-patient-symptoms"
                      onChange={(e) => setSymptoms(e.target.value)}
                      rows={3}
                      className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-50 text-sm transition-all resize-none"
                    />
                  </div>
                </div>
              </div>

              {/* Submit CTA */}
              <button
                type="submit"
                id="booking-form-submit-btn"
                className="w-full py-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs tracking-widest uppercase transition-all rounded-xl shadow-lg shadow-emerald-100 flex items-center justify-center gap-2 cursor-pointer"
              >
                <CalendarCheck className="w-5 h-5" />
                Confirm Doctor consultation
              </button>
            </form>
          </div>
        )}

        {/* Left Side: Interactive Sidebar Dashboard containing Appointments, Bookmarks, and Profile settings */}
        <div className="lg:col-span-5 bg-slate-900 text-white rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl sticky top-24">
          
          {/* Dashboard internal selectortabs */}
          <div className="flex bg-slate-800 p-1 rounded-xl border border-slate-800">
            <button
              onClick={() => setActiveSideTab('appointments')}
              className={`flex-1 py-2 text-[10px] font-mono font-black uppercase tracking-wider rounded-lg transition-all cursor-pointer ${
                activeSideTab === 'appointments' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Consultations ({appointments.length})
            </button>
            <button
              onClick={() => setActiveSideTab('lookings')}
              className={`flex-1 py-2 text-[10px] font-mono font-black uppercase tracking-wider rounded-lg transition-all cursor-pointer ${
                activeSideTab === 'lookings' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Lookings ({lookings.length})
            </button>
            <button
              onClick={() => setActiveSideTab('profile')}
              className={`flex-1 py-2 text-[10px] font-mono font-black uppercase tracking-wider rounded-lg transition-all cursor-pointer ${
                activeSideTab === 'profile' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Hub Specs
            </button>
          </div>

          <AnimatePresence mode="wait">
            {activeSideTab === 'appointments' && (
              <div className="space-y-4 max-h-[480px] overflow-y-auto pr-1 no-scrollbar animate-in fade-in duration-200">
                <div className="border-b border-slate-800 pb-3">
                  <span className="font-bold text-xs tracking-widest uppercase font-mono text-emerald-400 flex items-center gap-1.5">
                    <CalendarDays className="w-4 h-4 text-emerald-400" />
                    My Lobby Registrations
                  </span>
                  <p className="text-[10px] text-slate-400 mt-1 leading-relaxed">
                    Fetched reactive and safe from personal collection in Firestore.
                  </p>
                </div>

                {appointments.map((apt) => (
                  <div
                    key={apt.id}
                    id={`user-apt-card-${apt.id}`}
                    className="bg-slate-800/80 border border-slate-850 p-5 rounded-2xl relative space-y-3 block animate-in fade-in duration-200"
                  >
                    {/* Trash cancel button */}
                    <button
                      onClick={() => handleCancelAppointment(apt.id)}
                      id={`cancel-apt-btn-${apt.id}`}
                      className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-red-400 hover:bg-slate-700/50 transition-colors cursor-pointer"
                      title="Cancel this registration"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>

                    <div className="space-y-1">
                      <span className="inline-block px-2.5 py-0.5 rounded-lg bg-emerald-500/10 text-emerald-400 font-mono text-[9px] uppercase font-bold tracking-wider">
                        {apt.departmentName}
                      </span>
                      <h4 className="font-extrabold text-white text-sm tracking-tight">{apt.doctorName}</h4>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xxs font-mono text-slate-400 py-1">
                      <div>
                        <span className="block text-[8px] uppercase font-semibold text-slate-500 font-sans">DATE</span>
                        <span className="block font-bold text-slate-300">{apt.date}</span>
                      </div>
                      <div>
                        <span className="block text-[8px] uppercase font-semibold text-slate-500 font-sans">HOUR</span>
                        <span className="block font-bold text-slate-300">{apt.timeSlot}</span>
                      </div>
                    </div>

                    <div className="pt-2.5 border-t border-slate-700/60 font-sans">
                      <span className="block text-[8px] uppercase font-semibold text-slate-500 font-mono">PATIENT SYMPTOMS</span>
                      <span className="block text-slate-300 text-xxs leading-relaxed truncate mt-0.5">
                        {apt.patientName} — {apt.symptoms}
                      </span>
                    </div>
                  </div>
                ))}

                {appointments.length === 0 && (
                  <div className="py-16 text-center text-slate-500 space-y-3 bg-slate-800/20 border border-dashed border-slate-800 rounded-2xl">
                    <AlertCircle className="w-8 h-8 mx-auto text-slate-600 animate-pulse" />
                    <p className="text-xs font-mono">No active lobby slots found.</p>
                  </div>
                )}
              </div>
            )}

            {activeSideTab === 'lookings' && (
              <div className="space-y-4 max-h-[480px] overflow-y-auto pr-1 no-scrollbar animate-in fade-in duration-200">
                <div className="border-b border-slate-800 pb-3">
                  <span className="font-bold text-xs tracking-widest uppercase font-mono text-emerald-400 flex items-center gap-1.5">
                    <Bookmark className="w-4 h-4 text-emerald-400" />
                    My Saved Doctor Lookings
                  </span>
                  <p className="text-[10px] text-slate-400 mt-1 leading-relaxed">
                    Bookmarked clinical specialists saved to your profile interests list.
                  </p>
                </div>

                {lookings.map((look) => (
                  <div
                    key={look.id}
                    id={`user-look-card-${look.id}`}
                    className="bg-slate-800/80 border border-slate-850 p-4 rounded-2xl flex items-center justify-between gap-4 animate-in fade-in duration-150"
                  >
                    <div className="flex items-center gap-3">
                      <img 
                        src={look.doctorImage} 
                        alt={look.doctorName} 
                        referrerPolicy="no-referrer"
                        className="w-10 h-10 rounded-full object-cover border border-slate-700" 
                      />
                      <div>
                        <h4 className="font-bold text-white text-xs leading-none">{look.doctorName}</h4>
                        <span className="text-[10px] text-slate-400 font-mono block mt-1">{look.doctorRole}</span>
                      </div>
                    </div>

                    <button
                      onClick={() => handleRemoveLooking(look.id)}
                      id={`remove-look-btn-${look.id}`}
                      className="p-2 rounded-xl text-slate-400 hover:text-red-400 hover:bg-slate-700/50 transition-colors cursor-pointer"
                      title="Remove Bookmark"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}

                {lookings.length === 0 && (
                  <div className="py-16 text-center text-slate-500 space-y-3 bg-slate-800/20 border border-dashed border-slate-800 rounded-2xl">
                    <Heart className="w-8 h-8 mx-auto text-slate-600 animate-pulse" />
                    <p className="text-xs font-mono">No bookmarked specialists.</p>
                    <p className="text-[10px] text-slate-450">Click bookmark heart on Doctors tab to save them here!</p>
                  </div>
                )}
              </div>
            )}

            {activeSideTab === 'profile' && (
              <div className="animate-in fade-in duration-200 text-slate-100">
                <ProfileEditor 
                  completedCount={appointments.length} 
                  savedDoctorsCount={lookings.length}
                />
              </div>
            )}
          </AnimatePresence>

          <div className="pt-4 border-t border-slate-800 text-xxs text-slate-500 leading-relaxed font-mono space-y-1 flex items-start gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
            <span>Health Insurance card is scanned physically upon arrival. Please check in with OPD lobby front desk 15 minutes before slot hour starts.</span>
          </div>
        </div>
      </div>
    </div>
  );
}
