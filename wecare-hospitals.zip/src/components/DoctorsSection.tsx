import React, { useState, useMemo, useEffect } from 'react';
import { DOCTORS, DEPARTMENTS } from '../data';
import { Doctor } from '../types';
import { 
  Star, 
  Search, 
  MapPin, 
  Clock, 
  UserCheck, 
  Filter, 
  Award, 
  GraduationCap, 
  Stethoscope, 
  X, 
  CheckCircle,
  CalendarCheck,
  Heart
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { doc, setDoc, deleteDoc, collection, query, onSnapshot, serverTimestamp } from 'firebase/firestore';

interface DoctorsSectionProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  selectedDoctorId: string | null;
  setSelectedDoctorId: (docId: string | null) => void;
}

export default function DoctorsSection({
  activeTab,
  setActiveTab,
  selectedDoctorId,
  setSelectedDoctorId
}: DoctorsSectionProps) {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDeptFilter, setSelectedDeptFilter] = useState('all');
  const [viewedDoctor, setViewedDoctor] = useState<Doctor | null>(null);
  
  // Real-time tracking of booked lookings list
  const [savedDoctorIds, setSavedDoctorIds] = useState<Set<string>>(new Set());

  useEffect(() => {
    if (!user) {
      setSavedDoctorIds(new Set());
      return;
    }

    const path = `users/${user.uid}/lookings`;
    const q = query(collection(db, path));

    const unsubscribe = onSnapshot(q, (snapshot) => {
      try {
        const ids = new Set<string>();
        snapshot.docs.forEach(docSnap => {
          const d = docSnap.data();
          if (d.doctorId) ids.add(d.doctorId);
        });
        setSavedDoctorIds(ids);
      } catch (err) {
        handleFirestoreError(err, OperationType.GET, path);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, path);
    });

    return () => unsubscribe();
  }, [user]);

  const handleToggleLooking = async (e: React.MouseEvent, docItem: Doctor) => {
    e.stopPropagation(); // prevent triggering other clicks

    if (!user) {
      alert("Please log in on the 'Booking' tab to save your favorite doctor lookings inside your Patient Profile.");
      setActiveTab('booking');
      return;
    }

    const isCurrentlySaved = savedDoctorIds.has(docItem.id);
    const docRefPath = `users/${user.uid}/lookings/${docItem.id}`;
    
    try {
      if (isCurrentlySaved) {
        await deleteDoc(doc(db, `users/${user.uid}/lookings`, docItem.id));
      } else {
        await setDoc(doc(db, `users/${user.uid}/lookings`, docItem.id), {
          id: docItem.id,
          userId: user.uid,
          doctorId: docItem.id,
          doctorName: docItem.name,
          doctorRole: docItem.role,
          doctorImage: docItem.image,
          createdAt: serverTimestamp()
        });
      }
    } catch (err) {
      handleFirestoreError(err, isCurrentlySaved ? OperationType.DELETE : OperationType.CREATE, docRefPath);
    }
  };

  const filteredDoctors = useMemo(() => {
    return DOCTORS.filter((doc) => {
      const matchesSearch = 
        doc.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        doc.specialty.toLowerCase().includes(searchQuery.toLowerCase()) ||
        doc.bio.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesDept = selectedDeptFilter === 'all' || doc.departmentId === selectedDeptFilter;
      
      return matchesSearch && matchesDept;
    });
  }, [searchQuery, selectedDeptFilter]);

  const handleBookDoctor = (doctorId: string) => {
    setSelectedDoctorId(doctorId);
    setActiveTab('booking');
    setViewedDoctor(null);
  };

  const currentDeptName = useMemo(() => {
    if (selectedDeptFilter === 'all') return 'All Specialties';
    return DEPARTMENTS.find(d => d.id === selectedDeptFilter)?.name || '';
  }, [selectedDeptFilter]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20 space-y-12" id="doctors-section">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pt-6">
        <div className="space-y-3 max-w-xl">
          <span className="text-xs font-mono font-bold uppercase tracking-widest text-emerald-600">MEDICAL SENIOR STAFF</span>
          <h1 className="text-3xl font-bold text-slate-800 font-sans tracking-tight">
            Meet Our Senior Medical Specialists
          </h1>
          <p className="text-slate-500 text-sm leading-relaxed">
            Every consultant at WeCare Hospitals holds certified residency credentials and brings specialized clinical insights to diagnostic reviews.
          </p>
        </div>

        {/* Dynamic Name Search */}
        <div className="relative w-full md:w-80 shrink-0">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            id="doc-search-input"
            placeholder="Search by name, research, specialty..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-50 text-sm transition-all bg-white shadow-sm"
          />
        </div>
      </div>

      {/* Filter Tabs Row */}
      <div className="border-b border-slate-100 pb-2">
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-3 flex-wrap">
          <span className="text-xs font-mono font-bold text-slate-400 uppercase tracking-widest mr-2 flex items-center gap-1">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            Specialty:
          </span>
          
          <button
            onClick={() => setSelectedDeptFilter('all')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer ${
              selectedDeptFilter === 'all'
                ? 'bg-slate-800 text-white shadow-md'
                : 'bg-slate-50 text-slate-600 hover:bg-slate-100'
            }`}
          >
            All Departments
          </button>

          {DEPARTMENTS.map((dept) => (
            <button
              key={dept.id}
              onClick={() => setSelectedDeptFilter(dept.id)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer ${
                selectedDeptFilter === dept.id
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-100'
                  : 'bg-slate-50 text-slate-600 hover:bg-slate-100'
              }`}
            >
              {dept.name}
            </button>
          ))}
        </div>
      </div>

      {/* Doctors Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredDoctors.map((docItem) => {
          const dept = DEPARTMENTS.find(d => d.id === docItem.departmentId);
          const isSaved = savedDoctorIds.has(docItem.id);

          return (
            <div
              key={docItem.id}
              id={`doctor-card-${docItem.id}`}
              className="bg-white border border-slate-100 rounded-3xl overflow-hidden shadow-sm hover:shadow-lg transition-all duration-300 flex flex-col justify-between relative group"
            >
              {/* Bookmark Toggle Icon */}
              <button
                type="button"
                onClick={(e) => handleToggleLooking(e, docItem)}
                id={`toggle-bookmark-btn-${docItem.id}`}
                className="absolute top-4 right-4 z-10 w-10 h-10 rounded-full bg-white/90 backdrop-blur-md shadow-md border border-slate-100 flex items-center justify-center cursor-pointer transition-transform duration-200 active:scale-90"
                title={isSaved ? "Remove from lookings" : "Save doctor profile looking"}
              >
                <Heart 
                  className={`w-5 h-5 transition-colors ${
                    isSaved ? 'text-rose-500 fill-rose-500' : 'text-slate-400 hover:text-rose-500'
                  }`} 
                />
              </button>

              {/* Profile Image & Detail */}
              <div className="p-6 space-y-5">
                <div className="flex gap-4 items-start">
                  <div className="w-20 h-20 rounded-2xl overflow-hidden shrink-0 bg-slate-50 border border-slate-100 flex items-center justify-center">
                    <img
                      src={docItem.image}
                      alt={docItem.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  </div>

                  <div className="space-y-1 min-w-0 flex-1">
                    <h3 className="font-extrabold text-slate-800 text-base tracking-tight truncate">
                      {docItem.name}
                    </h3>
                    <span className="text-xxs font-bold font-mono text-emerald-600 uppercase tracking-wider block">
                      {docItem.role}
                    </span>
                    <span className="inline-block px-2 py-0.5 rounded-lg bg-slate-50 border border-slate-100 text-[10px] font-semibold text-slate-500 font-mono">
                      {dept?.name || 'Super Specialists'}
                    </span>
                  </div>
                </div>

                <div className="space-y-2 border-t border-b border-slate-50 py-4 text-xs font-medium">
                  <div className="flex items-center gap-2.5 text-slate-600">
                    <Stethoscope className="w-4 h-4 text-emerald-500 shrink-0" />
                    <span className="truncate">{docItem.specialty}</span>
                  </div>
                  <div className="flex items-center gap-2.5 text-slate-600">
                    <GraduationCap className="w-4 h-4 text-emerald-500 shrink-0" />
                    <span className="truncate">{docItem.education.split(',')[0]}</span>
                  </div>
                  <div className="flex items-center gap-2.5 text-slate-600">
                    <Award className="w-4 h-4 text-emerald-500 shrink-0" />
                    <span>{docItem.experience} Specialized Experience</span>
                  </div>
                </div>

                {/* Rating and Availability */}
                <div className="flex items-center justify-between text-xs pt-1">
                  <div className="flex items-center gap-1 font-bold text-amber-600 bg-amber-50 px-2.5 py-1 rounded-xl">
                    <Star className="w-3.5 h-3.5 fill-current" />
                    <span>{docItem.rating}</span>
                    <span className="text-slate-400 font-medium font-sans">({docItem.reviews})</span>
                  </div>

                  <div className="text-right">
                    <span className="block text-[10px] uppercase font-mono tracking-wider text-slate-400 font-bold">LOBBY HOURS</span>
                    <span className="block text-slate-600 font-bold text-xxs truncate">
                      {docItem.availability.days.slice(0, 2).join(' & ')} ({docItem.availability.slots.length} slots)
                    </span>
                  </div>
                </div>
              </div>

              {/* Card Actions */}
              <div className="px-6 pb-6 pt-2 grid grid-cols-2 gap-3 bg-slate-50/50 border-t border-slate-50">
                <button
                  onClick={() => setViewedDoctor(docItem)}
                  className="px-3 py-2.5 border border-slate-200 hover:bg-slate-100 text-slate-700 text-xs font-bold rounded-xl transition-all cursor-pointer"
                >
                  Full Bio Profile
                </button>
                <button
                  onClick={() => handleBookDoctor(docItem.id)}
                  id={`book-doctor-btn-${docItem.id}`}
                  className="px-3 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl text-center flex items-center justify-center gap-1 transition-all shadow-sm cursor-pointer hover:scale-[1.02] active:scale-[0.98]"
                >
                  <CalendarCheck className="w-3.5 h-3.5" />
                  InstaBook
                </button>
              </div>
            </div>
          );
        })}

        {filteredDoctors.length === 0 && (
          <div className="col-span-full py-16 text-center text-slate-400 space-y-4">
            <p className="text-sm font-medium">No medical experts match your query in {currentDeptName}.</p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedDeptFilter('all');
              }}
              className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-colors cursor-pointer"
            >
              Reset active filters
            </button>
          </div>
        )}
      </div>

      {/* Profile Detail Dialog / Modal */}
      {viewedDoctor && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-100 relative animate-in fade-in zoom-in-95 duration-200 animate-out duration-150">
            {/* Close Button */}
            <button
              onClick={() => setViewedDoctor(null)}
              className="absolute top-5 right-5 p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Modal Content */}
            <div className="p-8 space-y-6">
              {/* Doctor Quick Profile */}
              <div className="flex flex-col sm:flex-row gap-6 items-center sm:items-start text-center sm:text-left">
                <div className="w-28 h-28 rounded-2xl overflow-hidden shrink-0 bg-slate-50 border border-slate-100 shadow-md">
                  <img
                    src={viewedDoctor.image}
                    alt={viewedDoctor.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>

                <div className="space-y-2 flex-1">
                  <div>
                    <h3 className="text-2xl font-bold text-slate-800 tracking-tight leading-none flex items-center justify-center sm:justify-start gap-3">
                      <span>{viewedDoctor.name}</span>
                      <button
                        type="button"
                        onClick={(e) => handleToggleLooking(e, viewedDoctor)}
                        className="p-1.5 rounded-full hover:bg-slate-50 text-slate-400 hover:text-rose-500 cursor-pointer"
                        title={savedDoctorIds.has(viewedDoctor.id) ? "Remove Bookmark" : "Save doctor profile looking"}
                      >
                        <Heart 
                          className={`w-5 h-5 ${savedDoctorIds.has(viewedDoctor.id) ? 'text-rose-500 fill-rose-500' : ''}`} 
                        />
                      </button>
                    </h3>
                    <span className="text-xxs font-bold font-mono text-emerald-600 uppercase tracking-widest block mt-1.5">
                      {viewedDoctor.role}
                    </span>
                  </div>

                  <p className="text-xs text-slate-500 leading-relaxed max-w-md">
                    "{viewedDoctor.bio}"
                  </p>
                </div>
              </div>

              {/* Extensive Qualifications */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 border-t border-b border-slate-100 py-6 text-sm">
                <div className="space-y-3">
                  <span className="block text-xs uppercase font-mono tracking-widest text-slate-400 font-bold">QUALIFICATIONS</span>
                  <div className="space-y-2">
                    <div className="text-xs text-slate-700 font-medium">
                      <strong>Education:</strong> {viewedDoctor.education}
                    </div>
                    <div className="text-xs text-slate-700 font-medium">
                      <strong>Active Board Certification:</strong> Licensed Clinical Residency Specialist
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <span className="block text-xs uppercase font-mono tracking-widest text-slate-400 font-bold">LOBBY WORK HOURS</span>
                  <div className="space-y-2">
                    <div className="text-xs text-slate-700 font-medium">
                      <strong>Working Days:</strong> {viewedDoctor.availability.days.join(', ')}
                    </div>
                    <div className="text-xs text-slate-700 font-medium">
                      <strong>Available Slots Today:</strong> {viewedDoctor.availability.slots.slice(0, 3).join(', ')} ...
                    </div>
                  </div>
                </div>
              </div>

              {/* Dynamic Action Buttons inside modal */}
              <div className="flex justify-end gap-3 pt-2">
                <button
                  onClick={() => setViewedDoctor(null)}
                  className="px-5 py-3 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-bold transition-all cursor-pointer"
                >
                  Close Profile
                </button>
                <button
                  onClick={() => handleBookDoctor(viewedDoctor.id)}
                  id={`viewed-doctor-modal-book-btn`}
                  className="px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all shadow-md cursor-pointer"
                >
                  Reserve Instant Consultation
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
