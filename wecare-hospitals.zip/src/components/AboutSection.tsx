import { motion } from 'motion/react';
import { Award, Compass, Heart, Landmark, ShieldAlert, ShieldCheck, Sparkles, Building2, Eye, Goal } from 'lucide-react';

export default function AboutSection() {
  const milestones = [
    { year: '2012', title: 'WeCare Foundational Inception', desc: 'Inaugurated WeCare with a 40-bed primary care clinic, focused on compassionate community healing.' },
    { year: '2016', title: 'Major Cardiac Wing Expansion', desc: 'Doubled general beds and launched our Advanced 3D Echocardiography & Cardiac catheter laboratory.' },
    { year: '2020', title: 'JCI Global Accreditation Excellence', desc: 'Recognized with official gold seal from Joint Commission International, exceeding safety thresholds.' },
    { year: '2025', title: 'Robotics & Oncology Precision Labs', desc: 'Introduced targeted immune therapy panels and robotic-assisted clinical joint surgery tools.' }
  ];

  const values = [
    { icon: Heart, title: 'Patient-First Harmony', desc: 'Every treatment timeline, room temperature, and nurse round is engineered solely around restoring patient cheer and wellness.' },
    { icon: ShieldCheck, title: 'Uncompromising Safety', desc: 'We adhere strictly to evidence-based health parameters, operating zero-infection laminar airflows in surgical corridors.' },
    { icon: Sparkles, title: 'Continuous Science', desc: 'Our clinicians author international medical reviews and consistently validate new diagnostic technologies.' },
    { icon: Compass, title: 'Empathetic Delivery', desc: 'Medical recoveries require both clinical expertise and emotional encouragement. We support patient families deeply.' }
  ];

  return (
    <div className="space-y-20 pb-20 overflow-hidden" id="about-section">
      {/* Intro Header */}
      <section className="bg-gradient-to-br from-slate-50 to-emerald-50/10 py-16 border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <span className="text-xs font-mono font-bold tracking-widest text-emerald-600 uppercase">OUR STORY</span>
              <h1 className="text-4xl font-bold tracking-tight text-slate-800 font-sans leading-tight">
                Pioneering Clean, Humane, and Accessible Healthcare
              </h1>
              <p className="text-slate-600 leading-relaxed font-sans text-sm">
                Formed on the absolute certainty that medical execution must always pair with deep compassionate understanding, WeCare Hospitals has grown from a humble neighborhood clinic to a state-of-the-art super-specialty medical center.
              </p>
              <p className="text-slate-600 leading-relaxed font-sans text-sm">
                Today, our Golden Enclave campus matches top global research centers. Led by a board-certified clinical council and supported by hundreds of warm auxiliary medical nurses, we are setting new benchmarks of hospital excellence daily.
              </p>
            </div>

            <div className="relative">
              <div className="absolute -inset-2 bg-gradient-to-tr from-emerald-600 to-teal-500 rounded-2xl blur opacity-15 pointer-events-none" />
              <div className="relative bg-white p-3 rounded-2xl border border-slate-100 shadow-xl overflow-hidden aspect-[4/3]">
                <img 
                  src="https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?auto=format&fit=crop&q=80&w=800" 
                  alt="WeCare Hospitals Premium Medical Campus" 
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover rounded-xl grayscale-[10%]"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Vision & Mission Cards */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="bg-emerald-600 text-white rounded-3xl p-10 space-y-4 shadow-lg shadow-emerald-100 relative overflow-hidden group">
            <div className="absolute -right-10 -bottom-10 text-emerald-500 opacity-25 group-hover:scale-110 transition-transform duration-500">
              <Eye className="w-56 h-56" />
            </div>
            <div className="w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center text-white">
              <Eye className="w-6 h-6 animate-pulse" />
            </div>
            <h3 className="text-2xl font-bold font-sans">Our Strategic Vision</h3>
            <p className="text-emerald-50 leading-relaxed text-sm max-w-md">
              To be the most trusted, patient-centric healthcare network globally, renowned for seamless diagnostics, scientific innovation, and an elite community healing culture.
            </p>
          </div>

          <div className="bg-slate-900 text-white rounded-3xl p-10 space-y-4 shadow-lg relative overflow-hidden group">
            <div className="absolute -right-10 -bottom-10 text-slate-800 opacity-55 group-hover:scale-110 transition-transform duration-500">
              <Goal className="w-56 h-56" />
            </div>
            <div className="w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center text-emerald-400">
              <Goal className="w-6 h-6" />
            </div>
            <h3 className="text-2xl font-bold font-sans">Our Core Mission</h3>
            <p className="text-slate-300 leading-relaxed text-sm max-w-md">
              To deliver exceptional medical treatment through modern clinical infrastructure, highly ethical specialists, and dedicated research, providing safety, warmth, and relief to all.
            </p>
          </div>
        </div>
      </section>

      {/* Core Shared Values */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div className="text-center space-y-4 max-w-xl mx-auto">
          <span className="text-xs font-mono font-bold uppercase tracking-widest text-emerald-600">OUR PHILOSOPHY</span>
          <h2 className="text-3xl font-bold text-slate-800 font-sans tracking-tight">
            The WeCare Excellence Core
          </h2>
          <p className="text-slate-500 text-sm">
            Our medical staff operates under a strict ethical codex to ensure safety, precision clinical performance, and patient privacy.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {values.map((v, idx) => (
            <div key={idx} className="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm hover:shadow-md transition-all duration-300">
              <div className="w-10 h-10 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center mb-5">
                <v.icon className="w-5 h-5" />
              </div>
              <h4 className="text-base font-bold text-slate-800 mb-2">{v.title}</h4>
              <p className="text-slate-500 text-xs leading-relaxed">{v.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Milestone Timeline */}
      <section className="bg-slate-50 py-16 border-y border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          <div className="text-center space-y-4 max-w-xl mx-auto">
            <span className="text-xs font-mono font-bold uppercase tracking-widest text-emerald-600">HISTORIC EVOLUTION</span>
            <h2 className="text-3xl font-bold text-slate-800 font-sans tracking-tight">
              A Decade of Caring Milestones
            </h2>
            <p className="text-slate-500 text-sm">
              We continually enhance our capabilities, integrating technology with compassionate nursing.
            </p>
          </div>

          <div className="relative">
            {/* Center Line for desktop */}
            <div className="absolute left-1/2 top-0 bottom-0 w-0.5 bg-slate-200 -translate-x-1/2 hidden lg:block" />

            <div className="space-y-12 relative z-10">
              {milestones.map((m, idx) => {
                const isEven = idx % 2 === 0;
                return (
                  <div key={idx} className={`flex flex-col lg:flex-row items-center gap-8 ${isEven ? '' : 'lg:flex-row-reverse'}`}>
                    {/* Left Space on desktop */}
                    <div className="w-full lg:w-1/2 flex justify-end">
                      {isEven ? (
                        <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm max-w-md w-full">
                          <span className="inline-block px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 font-mono font-bold text-xs mb-3">
                            {m.year}
                          </span>
                          <h4 className="text-base font-bold text-slate-800 mb-2">{m.title}</h4>
                          <p className="text-slate-500 text-xs leading-relaxed">{m.desc}</p>
                        </div>
                      ) : null}
                    </div>

                    {/* Timeline Node Badge Button */}
                    <div className="w-10 h-10 rounded-full bg-emerald-600 text-white font-mono font-bold text-xs flex items-center justify-center border-4 border-white shadow-md z-10 shrink-0">
                      {m.year.substring(2)}
                    </div>

                    {/* Right Space on desktop */}
                    <div className="w-full lg:w-1/2 flex justify-start">
                      {!isEven ? (
                        <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm max-w-md w-full">
                          <span className="inline-block px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 font-mono font-bold text-xs mb-3">
                            {m.year}
                          </span>
                          <h4 className="text-base font-bold text-slate-800 mb-2">{m.title}</h4>
                          <p className="text-slate-500 text-xs leading-relaxed">{m.desc}</p>
                        </div>
                      ) : null}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* Hospital Infrastructure & Facility Features */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-slate-900 rounded-3xl p-8 sm:p-12 text-white relative overflow-hidden">
          <div className="absolute top-0 left-0 w-96 h-96 bg-emerald-600/10 rounded-full blur-3xl pointer-events-none" />
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center relative z-10">
            <div className="lg:col-span-5 space-y-6">
              <span className="text-xs font-mono font-bold tracking-widest text-emerald-400 uppercase">State-of-Art Infrastructure</span>
              <h3 className="text-2xl sm:text-3xl font-bold font-sans">
                A Healing Environment Designed to Excel
              </h3>
              <p className="text-slate-300 text-xs leading-relaxed">
                Clean and safety-optimized designs aid the subconscious reduction of clinical stress, accelerating cellular healing. WeCare invests immensely in silent heating ventilation cooling systems, sterile anti-microbial paint, and warm daylight emulation light tubes.
              </p>
              
              <div className="grid grid-cols-2 gap-4 pt-2 text-xs font-mono font-bold tracking-wider">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-400" />
                  <span>HEPA Clean corridors</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-400" />
                  <span>Ultra-silent ICU zones</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-400" />
                  <span>Water treatment plant</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-400" />
                  <span>Zero-noise environment</span>
                </div>
              </div>
            </div>

            <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-3 gap-6">
              {[
                { title: 'Biochemistry Panel', desc: 'Real-time diagnostic array for direct biomarker profiling.' },
                { title: 'Super-Slice MRI', desc: 'High resolution digital scanning with zero acoustic disturbance.' },
                { title: 'Laminar Air Surgery', desc: 'Surgical chambers featuring vertical airflow to secure sterility.' }
              ].map((fac, idx) => (
                <div key={idx} className="bg-slate-800/60 border border-slate-800/60 p-5 rounded-2xl flex flex-col justify-between h-44">
                  <span className="text-2xl font-bold font-mono text-emerald-400">0{idx+1}</span>
                  <div className="mt-4">
                    <h4 className="text-sm font-bold text-white mb-1">{fac.title}</h4>
                    <p className="text-xxs text-slate-400 leading-normal">{fac.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
