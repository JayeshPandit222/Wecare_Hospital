import { Department, Doctor, Testimonial, FAQ } from './types';

export const DEPARTMENTS: Department[] = [
  {
    id: 'cardiology',
    name: 'Cardiology',
    description: 'Comprehensive heart care including diagnostic, preventive, and surgical services powered by state-of-the-art tech.',
    iconName: 'Heart',
    longDescription: 'Our Cardiology Department is a world-class center of excellence. We offer dedicated heart care services from preventative screenings to sophisticated diagnostic imaging, complex interventional procedures, heart failure management, and cardiac rehabilitation. We utilize advanced medical devices and minimally invasive procedures to ensure the best patient experiences.',
    specialties: ['Coronary Artery Disease', 'Heart Failure Management', 'Electrophysiology', 'Interventional Cardiology', 'Preventative Cardiology'],
    stats: [
      { label: 'Surgeries/Yr', value: '1,200+' },
      { label: 'Success Rate', value: '99.2%' },
      { label: 'Specialists', value: '8 Senior' }
    ]
  },
  {
    id: 'pediatrics',
    name: 'Pediatrics',
    description: 'Expert compassionate care for infants, children, and adolescents in a warm, friendly environment.',
    iconName: 'Baby',
    longDescription: 'The Pediatrics Department at WeCare provides tailored medical, surgical, and developmental care for children. From regular immunization schedules to complex childhood disorders, our specialized pediatricians foster a comfortable and fear-free environment. We are focused on emotional & physical growth and well-being.',
    specialties: ['Neonatology', 'Pediatric Allergy', 'Child Development', 'Pediatric Cardiology', 'Adolescent Medicine'],
    stats: [
      { label: 'Happy Families', value: '15k+' },
      { label: 'Vaccinations', value: '40k+' },
      { label: 'Child Friendly Playrooms', value: '4' }
    ]
  },
  {
    id: 'neurology',
    name: 'Neurology',
    description: 'Advanced diagnosis and advanced treatment of complex disorders of the brain, spinal cord, and nervous system.',
    iconName: 'Brain',
    longDescription: 'Our specialized Neurology team handles comprehensive diagnostics and therapeutic options for strokes, neuromuscular conditions, epilepsy, Parkinson’s disease, Alzheimer’s, migraines, and cognitive disorders. Our integrated neuro-imaging and neuro-rehabilitation programs are designed to restore function and improve standard of living.',
    specialties: ['Stroke Intervention', 'Epilepsy Care', 'Neurodegenerative Diseases', 'Sleep Disorders', 'Neuromuscular Pathology'],
    stats: [
      { label: 'Neuro-ICU Beds', value: '25' },
      { label: 'EEG/EMG Scans/Yr', value: '5,000+' },
      { label: 'Clinical Trials Active', value: '12' }
    ]
  },
  {
    id: 'orthopedics',
    name: 'Orthopedics & Joint Care',
    description: 'A dedicated team focusing on restoration of bone, muscle, joint fitness, and musculoskeletal rehab.',
    iconName: 'Activity',
    longDescription: 'The Orthopedics Department focuses on diagnosing, correcting, and treating skeletal deformities, fractures, sports injuries, and degenerative joint diseases. Our expertise includes robotic joint replacements, keyhole arthroscopic surgeries, spine therapies, and dedicated occupational therapy systems.',
    specialties: ['Robotic Knee/Hip Replacement', 'Sports Medicine & Arthroscopy', 'Spine Reconstruction', 'Pediatric Orthopedics', 'Trauma & Fracture Care'],
    stats: [
      { label: 'Joint Replacements', value: '800+' },
      { label: 'Rehab Success', value: '98.5%' },
      { label: 'Sports Therapists', value: '12 Certified' }
    ]
  },
  {
    id: 'oncology',
    name: 'Oncology Center',
    description: 'Multidisciplinary tumor boards, precision immunotherapy, chemotherapy, and support for ultimate recovery.',
    iconName: 'ShieldAlert',
    longDescription: 'Our oncology department integrates chemotherapy, radiation oncology, immunotherapy, and cancer surgery in a personalized approach. Every patient is guided by a multidisciplinary Tumor Board of experts to design the safest, most effective route. We offer extensive emotional and palliative support programs.',
    specialties: ['Medical Oncology', 'Surgical Oncology', 'Radiation Therapy', 'Immunotherapy & Target Trial', 'Palliative & Supportive Care'],
    stats: [
      { label: 'Tumor Board Cases/Yr', value: '2,400' },
      { label: 'Survivor Network', value: '8k+' },
      { label: 'Linear Accelerators', value: '2 State-Art' }
    ]
  }
];

export const DOCTORS: Doctor[] = [
  {
    id: 'dr-adrian-vance',
    name: 'Dr. Adrian Vance',
    departmentId: 'cardiology',
    role: 'Chief Cardiologist',
    image: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&q=80&w=600',
    rating: 4.9,
    reviews: 247,
    specialty: 'Interventional Cardiology & Coronary Angioplasty',
    experience: '18 Years',
    education: 'MD - Harvard Medical School, DM - Cardiology (Johns Hopkins)',
    availability: {
      days: ['Monday', 'Tuesday', 'Thursday'],
      slots: ['09:00 AM', '10:30 AM', '11:00 AM', '02:00 PM', '03:30 PM']
    },
    bio: 'Dr. Adrian Vance is a pioneer in zero-contrast angioplasty and complex coronary anatomy treatments. He is passionate about reducing patient recovery intervals via minimally invasive catheter interventions.'
  },
  {
    id: 'dr-sarah-jenkins',
    name: 'Dr. Sarah Jenkins',
    departmentId: 'cardiology',
    role: 'Senior Consultant, Non-Invasive Cardiology',
    image: 'https://images.unsplash.com/photo-1594824813573-246434de83fb?auto=format&fit=crop&q=80&w=600',
    rating: 4.8,
    reviews: 189,
    specialty: 'Preventative Cardiology & 3D Echocardiography',
    experience: '12 Years',
    education: 'MD - Stanford Health Sciences, Fellowship in Echocardiography (Mayo Clinic)',
    availability: {
      days: ['Wednesday', 'Thursday', 'Friday'],
      slots: ['10:00 AM', '11:30 AM', '01:30 PM', '03:00 PM', '04:30 PM']
    },
    bio: 'Dr. Jenkins focuses on preventative strategies and precise non-invasive cardiac scanning. She works closely with patients on lifestyle and metabolic optimization to reduce cardiac event factors.'
  },
  {
    id: 'dr-emily-thorne',
    name: 'Dr. Emily Thorne',
    departmentId: 'pediatrics',
    role: 'Head of Pediatric Medicine',
    image: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=600',
    rating: 4.9,
    reviews: 312,
    specialty: 'Neonatal Critical Care & Pediatric Allergy Management',
    experience: '15 Years',
    education: 'MD - Yale School of Medicine, Board Certified Pediatrician (AAP)',
    availability: {
      days: ['Monday', 'Wednesday', 'Friday'],
      slots: ['08:30 AM', '09:30 AM', '10:30 AM', '02:00 PM', '04:00 PM']
    },
    bio: 'Dr. Emily Thorne brings a gentle touch and exceptional warmth to her practice. She specializes in newborn clinical diagnostics and chronic allergic asthma management in young kids.'
  },
  {
    id: 'dr-marcus-vance',
    name: 'Dr. Marcus Vance',
    departmentId: 'pediatrics',
    role: 'Consultant Pediatrician & Adolescent Specialist',
    image: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?auto=format&fit=crop&q=80&w=600',
    rating: 4.7,
    reviews: 115,
    specialty: 'Child Growth Dynamics & Adolescent Psychological Health',
    experience: '9 Years',
    education: 'MD - Columbia College of Physicians & Surgeons',
    availability: {
      days: ['Tuesday', 'Thursday', 'Saturday'],
      slots: ['09:00 AM', '11:00 AM', '01:00 PM', '02:30 PM', '03:30 PM']
    },
    bio: 'Dr. Marcus Vance covers adolescent behavioral development and holistic adolescent nutrition. He organizes child-friendly medical educational camps and emphasizes patient-family centered care.'
  },
  {
    id: 'dr-charles-sterling',
    name: 'Dr. Charles Sterling',
    departmentId: 'neurology',
    role: 'Director of Neurology & Stroke Unit',
    image: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?auto=format&fit=crop&q=80&w=600',
    rating: 5.0,
    reviews: 402,
    specialty: 'Acute Stroke Intervention & Cognitive Rehabilitation',
    experience: '22 Years',
    education: 'MD - Oxford Medical, PhD - Neurophysiology (UC Berkeley)',
    availability: {
      days: ['Monday', 'Tuesday', 'Friday'],
      slots: ['09:00 AM', '10:00 AM', '03:00 PM', '04:00 PM', '05:00 PM']
    },
    bio: 'Dr. Charles Sterling is globally acclaimed for stroke thrombolysis research. He serves as principal inspector for novel medication regimes targeting neuromuscular sclerosis.'
  },
  {
    id: 'dr-elena-rostova',
    name: 'Dr. Elena Rostova',
    departmentId: 'neurology',
    role: 'Senior Consultant Neuro-Pathologist',
    image: 'https://images.unsplash.com/photo-1591604021695-0c69b7c05981?auto=format&fit=crop&q=80&w=600',
    rating: 4.8,
    reviews: 143,
    specialty: 'Epilepsy Protocols & Clinical EEG analysis',
    experience: '14 Years',
    education: 'MD - Saint Petersburg State University, Fellowship (King’s College London)',
    availability: {
      days: ['Wednesday', 'Thursday', 'Friday'],
      slots: ['10:30 AM', '11:30 AM', '01:30 PM', '02:30 PM', '04:30 PM']
    },
    bio: 'Dr. Rostova specializes in epilepsy surgical screenings and video EEG monitoring. Her clinical trials on medication-resistant epilepsy are widely acknowledged in Europe.'
  },
  {
    id: 'dr-james-carter',
    name: 'Dr. James Carter',
    departmentId: 'orthopedics',
    role: 'Chief Orthopedic Surgeon',
    image: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&q=80&w=600&id=jc',
    rating: 4.9,
    reviews: 328,
    specialty: 'Robotic Total Joint Replacement & Complex Trauma Reconstruction',
    experience: '17 Years',
    education: 'MD - University of Chicago, Residency (Hospital for Special Surgery, NY)',
    availability: {
      days: ['Monday', 'Wednesday', 'Thursday'],
      slots: ['08:00 AM', '09:30 AM', '11:00 AM', '02:00 PM', '04:00 PM']
    },
    bio: 'Dr. Carter is a pioneer in minimally invasive tissue-saving knee and hip replacements, helping seniors regain complete mobility. He acts as advisor to major sports organizations.'
  },
  {
    id: 'dr-sophia-martinez',
    name: 'Dr. Sophia Martinez',
    departmentId: 'orthopedics',
    role: 'Consultant in Sports Medicine',
    image: 'https://images.unsplash.com/photo-1527613426441-4da17471b66d?auto=format&fit=crop&q=80&w=600',
    rating: 4.8,
    reviews: 212,
    specialty: 'Keyhole Arthroscopic Joint Surgery & Tendon Repair',
    experience: '11 Years',
    education: 'MD - UT Southwestern Medical Center, Fellowship (UCSF Orthopaedic Trauma)',
    availability: {
      days: ['Tuesday', 'Friday', 'Saturday'],
      slots: ['09:00 AM', '10:30 AM', '12:00 PM', '01:30 PM', '03:00 PM']
    },
    bio: 'Dr. Sophia Martinez specializes in shoulder and cruciate ligament arthroscopic reconstructions. She focuses on custom-paced active recover regimens for professional and recreational athletes alike.'
  },
  {
    id: 'dr-robert-chen',
    name: 'Dr. Robert Chen',
    departmentId: 'oncology',
    role: 'Chief Medical Oncologist',
    image: 'https://images.unsplash.com/photo-1637059824899-a441006a6875?auto=format&fit=crop&q=80&w=600',
    rating: 4.9,
    reviews: 345,
    specialty: 'Immunotherapy, Custom Targeted Chemotherapies',
    experience: '19 Years',
    education: 'MD - Johns Hopkins University School of Medicine, Board Certified Medical Oncologist',
    availability: {
      days: ['Monday', 'Tuesday', 'Wednesday'],
      slots: ['09:30 AM', '11:00 AM', '02:00 PM', '03:00 PM', '04:30 PM']
    },
    bio: 'Dr. Robert Chen is committed to designing precise therapies that target the molecular genome of tumors, minimizing side effects. He actively mentors research fellows in medical trial systems.'
  },
  {
    id: 'dr-clara-dupont',
    name: 'Dr. Clara Dupont',
    departmentId: 'oncology',
    role: 'Senior Oncological Breast & Soft Tissue Specialist',
    image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=600',
    rating: 4.9,
    reviews: 218,
    specialty: 'Surgical Resections & Patient Focused Lumpectomy',
    experience: '13 Years',
    education: 'MD - Sorbonne Paris, Fellow (Sloan Kettering Cancer Center)',
    availability: {
      days: ['Tuesday', 'Thursday', 'Friday'],
      slots: ['08:30 AM', '10:00 AM', '11:30 AM', '02:30 PM', '04:00 PM']
    },
    bio: 'Dr. Dupont takes extra care to plan aesthetic outcomes during oncological resections. Her clinical study is directed at non-invasive margins and localized targeted radiotherapies.'
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 't1',
    name: 'Arthur Pendelton',
    age: 64,
    relation: 'Cardiac Patient',
    text: 'The absolute care Dr. Adrian Vance took to explain my coronary condition removed all fear. The procedures at WeCare are truly cutting edge, and the nursing staff are real angels!',
    rating: 5,
    department: 'Cardiology'
  },
  {
    id: 't2',
    name: 'Clara Jenkins (For Baby Timmy)',
    age: 28,
    relation: 'Mother of Patient',
    text: 'Dr. Emily Thorne was so extremely warm that Timmy didn’t cry even once during his immunization list! The pediatric rooms are basically a theme park, so lighthearted and joyful.',
    rating: 5,
    department: 'Pediatrics'
  },
  {
    id: 't3',
    name: 'Marcus Sterling Jr.',
    age: 42,
    relation: 'Physical Rehab Patient',
    text: 'My knee arthroscopy with Dr. Sophia Martinez was seamless. I was back on the local tracks running safely in under eight weeks. Forever grateful for WeCare’s custom sports rehabilitative programs.',
    rating: 5,
    department: 'Orthopedics & Joint Care'
  },
  {
    id: 't4',
    name: 'Rebecca Miller',
    age: 51,
    relation: 'Stroke Survivor',
    text: 'The rapid, timely intervention of WeCare’s stroke response team under Dr. Charles Sterling literally saved my life and motor functions. Their multidisciplinary post-stroke rehab was incredibly meticulous.',
    rating: 5,
    department: 'Neurology'
  }
];

export const FAQS: FAQ[] = [
  {
    id: 'faq-1',
    question: 'How do I schedule an appointment online?',
    answer: 'You can easily book online by navigating to our dedicated "Book Appointment" section. Choose your desired department, select your specialized doctor, choose a comfortable date & timeslot, fill in your details, and book! It takes less than 2 minutes and updates in real-time.',
    category: 'Booking Process'
  },
  {
    id: 'faq-2',
    question: 'Are walk-ins allowed if I don’t book online?',
    answer: 'Yes! Walk-in registrations are open at our main desk 24/7. However, to minimize your wait time, we highly recommend booking your slot online beforehand as online bookings get priority status.',
    category: 'General'
  },
  {
    id: 'faq-3',
    question: 'Is WeCare Hospital in-network for major medical insurance?',
    answer: 'Absolutely. WeCare Hospitals partnered with all major domestic and international health insurance providers. You can upload or submit your policy cards during patient registration or contact our desk for help.',
    category: 'Insurance & Billing'
  },
  {
    id: 'faq-4',
    question: 'What are the timing schedules of visiting hours for intensive wards?',
    answer: 'To prioritize inpatient healing, general visiting hours are 10:00 AM – 12:00 PM and 04:00 PM – 07:00 PM daily. Only immediate family and caregivers are allowed inside the Cardiac & Neuro ICU units with specific tags.',
    category: 'General'
  },
  {
    id: 'faq-5',
    question: 'Does the hospital provide round-the-clock emergency support?',
    answer: 'Yes, WeCare features a Level-1 Trauma Emergency Ward that functions round-the-clock (24 hours a day, 365 days a year) with highly trained critical care intensivists standing by.',
    category: 'Emergency'
  }
];
