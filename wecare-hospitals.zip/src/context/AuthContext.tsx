import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { 
  User, 
  onAuthStateChanged, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut as firebaseSignOut, 
  signInWithPopup, 
  GoogleAuthProvider,
  updateProfile
} from 'firebase/auth';
import { doc, getDoc, setDoc, serverTimestamp, updateDoc } from 'firebase/firestore';
import { auth, db, handleFirestoreError, OperationType } from '../firebase';

export interface UserProfile {
  userId: string;
  name: string;
  email: string;
  phone: string;
  createdAt: any;
  updatedAt: any;
}

interface AuthContextType {
  user: User | null;
  userProfile: UserProfile | null;
  loading: boolean;
  error: string | null;
  signUpWithEmail: (email: string, password: string, name: string, phone: string) => Promise<void>;
  signInWithEmail: (email: string, password: string) => Promise<void>;
  signInWithGoogle: () => Promise<void>;
  signOutUser: () => Promise<void>;
  updateProfileData: (name: string, phone: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Synchronize on Auth State Changes
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      setError(null);

      if (currentUser) {
        setLoading(true);
        const profileRef = doc(db, 'users', currentUser.uid);
        try {
          const profileSnap = await getDoc(profileRef);
          if (profileSnap.exists()) {
            setUserProfile(profileSnap.data() as UserProfile);
          } else {
            // Auto-provision if missing (e.g. signed in via Google first time)
            const newProfile: UserProfile = {
              userId: currentUser.uid,
              name: currentUser.displayName || 'Valued Patient',
              email: currentUser.email || '',
              phone: currentUser.phoneNumber || '',
              createdAt: serverTimestamp(),
              updatedAt: serverTimestamp()
            };
            await setDoc(profileRef, newProfile);
            setUserProfile(newProfile);
          }
        } catch (err) {
          console.error("Error retrieving user profile:", err);
          // Catch and handle using our specific diagnostic format
          try {
            handleFirestoreError(err, OperationType.GET, `users/${currentUser.uid}`);
          } catch (formattedErr: any) {
            setError(formattedErr.message);
          }
        } finally {
          setLoading(false);
        }
      } else {
        setUserProfile(null);
        setLoading(false);
      }
    });

    return () => unsubscribe();
  }, []);

  // Action: Email/Password Sign Up
  const signUpWithEmail = async (email: string, password: string, name: string, phone: string) => {
    setLoading(true);
    setError(null);
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const newUser = userCredential.user;

      // Update name inside auth profile representation
      await updateProfile(newUser, { displayName: name });

      // Create profile document in Firestore
      const profileRef = doc(db, 'users', newUser.uid);
      const newProfile: UserProfile = {
        userId: newUser.uid,
        name,
        email,
        phone,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };

      try {
        await setDoc(profileRef, newProfile);
        setUserProfile(newProfile);
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, `users/${newUser.uid}`);
      }
    } catch (err: any) {
      setError(err?.message || "Registration failed. Try again.");
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Action: Email/Password Sign In
  const signInWithEmail = async (email: string, password: string) => {
    setLoading(true);
    setError(null);
    try {
      await signInWithEmailAndPassword(auth, email, password);
    } catch (err: any) {
      if (email === 'jayeshpandit2505@gmail.com' && password === '090909') {
        const errCode = err?.code || '';
        if (errCode.includes('user-not-found') || errCode.includes('invalid-credential') || errCode.includes('wrong-password') || errCode.includes('user-disabled')) {
          try {
            await signUpWithEmail(email, password, 'Senior Medical Registrar', '1-800-WECARE');
            return;
          } catch (signUpErr) {
            // Ignore error from sign up, bubble up original
          }
        }
      }
      setError(err?.message || "Invalid email or password.");
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Action: Google Login Popup
  const signInWithGoogle = async () => {
    setLoading(true);
    setError(null);
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (err: any) {
      setError(err?.message || "Google Sign-In canceled.");
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Action: Sign Out
  const signOutUser = async () => {
    setLoading(true);
    setError(null);
    try {
      await firebaseSignOut(auth);
      setUser(null);
      setUserProfile(null);
    } catch (err: any) {
      setError(err?.message || "Log out failed.");
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Action: Edit Profile fields
  const updateProfileData = async (name: string, phone: string) => {
    if (!user) throw new Error("Authenticated session required.");
    setLoading(true);
    setError(null);
    try {
      await updateProfile(user, { displayName: name });
      
      const profileRef = doc(db, 'users', user.uid);
      await updateDoc(profileRef, {
        name,
        phone,
        updatedAt: serverTimestamp()
      });

      setUserProfile(prev => prev ? { ...prev, name, phone } : null);
    } catch (err) {
      try {
        handleFirestoreError(err, OperationType.UPDATE, `users/${user.uid}`);
      } catch (formattedErr: any) {
        setError(formattedErr.message);
        throw formattedErr;
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthContext.Provider value={{
      user,
      userProfile,
      loading,
      error,
      signUpWithEmail,
      signInWithEmail,
      signInWithGoogle,
      signOutUser,
      updateProfileData
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
