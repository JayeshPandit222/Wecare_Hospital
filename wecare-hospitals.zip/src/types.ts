export interface Doctor {
  id: string;
  name: string;
  departmentId: string;
  role: string;
  image: string;
  rating: number;
  reviews: number;
  specialty: string;
  experience: string;
  education: string;
  availability: {
    days: string[];
    slots: string[];
  };
  bio: string;
}

export interface Department {
  id: string;
  name: string;
  description: string;
  iconName: string;
  longDescription: string;
  specialties: string[];
  stats: {
    label: string;
    value: string;
  }[];
}

export interface Appointment {
  id: string;
  userId: string;
  doctorId: string;
  doctorName: string;
  departmentId: string;
  departmentName: string;
  patientName: string;
  patientEmail: string;
  patientPhone: string;
  date: string;
  timeSlot: string;
  symptoms: string;
  status: 'Scheduled' | 'Completed' | 'Cancelled';
  createdAt: string;
}

export interface Testimonial {
  id: string;
  name: string;
  age: number;
  relation: string;
  text: string;
  rating: number;
  department: string;
}

export interface FAQ {
  id: string;
  question: string;
  answer: string;
  category: string;
}
